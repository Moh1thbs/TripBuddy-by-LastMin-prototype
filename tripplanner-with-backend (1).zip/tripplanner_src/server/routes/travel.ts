import { Router, Request, Response } from 'express';
import { fetchHotels } from '../adapters/hotels.js';
import { fetchRestaurants } from '../adapters/restaurants.js';
import { fetchTransport } from '../adapters/transport.js';
import { TransportMode, TravelServiceParams } from '../../shared/mockTravelData.js';

export const travelRouter = Router();

const VALID_MODES: TransportMode[] = ['Flight', 'Train', 'Bus', 'Car', 'Cruise'];

function parseParams(req: Request, res: Response): TravelServiceParams | null {
  const destination = String(req.query.destination || '').trim();
  const startDate = String(req.query.startDate || '').trim();
  const durationDays = Number(req.query.durationDays);
  const transportMode = String(req.query.transportMode || 'Flight') as TransportMode;

  if (!destination) {
    res.status(400).json({ error: 'Query param "destination" is required.' });
    return null;
  }
  if (!startDate || Number.isNaN(Date.parse(startDate))) {
    res.status(400).json({ error: 'Query param "startDate" must be a valid date (YYYY-MM-DD).' });
    return null;
  }
  if (!Number.isFinite(durationDays) || durationDays <= 0 || durationDays > 90) {
    res.status(400).json({ error: 'Query param "durationDays" must be a number between 1 and 90.' });
    return null;
  }
  if (!VALID_MODES.includes(transportMode)) {
    res.status(400).json({ error: `Query param "transportMode" must be one of ${VALID_MODES.join(', ')}.` });
    return null;
  }

  return { destination, startDate, durationDays, transportMode };
}

travelRouter.get('/hotels', async (req, res) => {
  const params = parseParams(req, res);
  if (!params) return;
  try {
    res.json(await fetchHotels(params));
  } catch (err) {
    console.error('[GET /api/hotels]', err);
    res.status(502).json({ error: 'Failed to fetch hotel recommendations.' });
  }
});

travelRouter.get('/restaurants', async (req, res) => {
  const params = parseParams(req, res);
  if (!params) return;
  try {
    res.json(await fetchRestaurants(params));
  } catch (err) {
    console.error('[GET /api/restaurants]', err);
    res.status(502).json({ error: 'Failed to fetch restaurant recommendations.' });
  }
});

travelRouter.get('/transport', async (req, res) => {
  const params = parseParams(req, res);
  if (!params) return;
  try {
    res.json(await fetchTransport(params));
  } catch (err) {
    console.error('[GET /api/transport]', err);
    res.status(502).json({ error: 'Failed to fetch transport options.' });
  }
});

import rateLimit from 'express-rate-limit';

// 60 requests/minute per IP is generous for normal browsing but stops a
// runaway frontend loop (or a scraper) from burning through your Google
// Places quota.
export const apiRateLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please slow down.' },
});

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import path from 'path';
import { fileURLToPath } from 'url';
import { travelRouter } from './routes/travel.js';
import { apiRateLimiter } from './lib/rateLimiter.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = Number(process.env.PORT) || 8787;
const NODE_ENV = process.env.NODE_ENV || 'development';
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN; // e.g. "https://your-frontend.example.com"

const app = express();

// Cloud Run and most PaaS put the app behind a proxy; needed for correct
// client IPs in the rate limiter and for secure cookies if you add auth later.
app.set('trust proxy', 1);

app.use(helmet());
app.use(
  cors({
    // In dev, Vite's proxy makes requests same-origin so this is permissive;
    // in prod, lock it down via ALLOWED_ORIGIN once you know your domain.
    origin: ALLOWED_ORIGIN || (NODE_ENV === 'production' ? false : true),
  })
);
app.use(express.json());

app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', env: NODE_ENV, placesApiConfigured: Boolean(process.env.GOOGLE_PLACES_API_KEY) });
});

app.use('/api', apiRateLimiter, travelRouter);

// In production, serve the built frontend from the same Express process —
// one Cloud Run service instead of two things to deploy and keep in sync.
if (NODE_ENV === 'production') {
  const distPath = path.resolve(__dirname, '..', 'dist');
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.use((_req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.listen(PORT, () => {
  console.log(`TripPlanner API listening on http://localhost:${PORT} (${NODE_ENV})`);
  if (!process.env.GOOGLE_PLACES_API_KEY) {
    console.log('  ↳ GOOGLE_PLACES_API_KEY not set — hotel/restaurant endpoints are serving mock data.');
  }
});

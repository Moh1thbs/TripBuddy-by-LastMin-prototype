import { generateMockTransport, TravelServiceParams } from '../../shared/mockTravelData.js';
import { TTLCache } from '../lib/cache.js';

const cache = new TTLCache<any[]>(10 * 60 * 1000);

// No transport adapter is wired to a live provider by default — flight/rail
// search APIs (Amadeus, Skyscanner, Trainline) require paid tiers or an
// OAuth handshake, so this stays a clean plug-in point.
//
// To wire one in:
//   1. Add its secret key to `.env` (server-side only, no VITE_ prefix).
//   2. Implement `fetchFromLiveProvider(params)` below returning
//      `TransportOption[]` in the same shape as `generateMockTransport`.
//   3. Set `LIVE_TRANSPORT_ENABLED = Boolean(process.env.YOUR_KEY)`.

const LIVE_TRANSPORT_ENABLED = false;

async function fetchFromLiveProvider(_params: TravelServiceParams): Promise<any[]> {
  throw new Error('No live transport provider configured yet.');
}

export async function fetchTransport(params: TravelServiceParams) {
  const key = TTLCache.keyFrom({ dest: params.destination, days: params.durationDays, mode: params.transportMode, type: 'transport' });
  const cached = cache.get(key);
  if (cached) return cached;

  let result;
  if (LIVE_TRANSPORT_ENABLED) {
    try {
      result = await fetchFromLiveProvider(params);
    } catch (err) {
      console.error('[transport] live provider lookup failed, falling back to mock data:', err);
      result = generateMockTransport(params);
    }
  } else {
    result = generateMockTransport(params);
  }

  cache.set(key, result);
  return result;
}

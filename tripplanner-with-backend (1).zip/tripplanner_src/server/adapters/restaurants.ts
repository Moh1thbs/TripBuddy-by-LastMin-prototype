import { generateMockRestaurants, createRestaurantReservationLink, TravelServiceParams } from '../../shared/mockTravelData.js';
import { TTLCache } from '../lib/cache.js';

const cache = new TTLCache<any[]>(10 * 60 * 1000);
const PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY || '';

function priceLevelToRange(level?: string): '$' | '$$' | '$$$' | '$$$$' {
  switch (level) {
    case 'PRICE_LEVEL_FREE':
    case 'PRICE_LEVEL_INEXPENSIVE':
      return '$';
    case 'PRICE_LEVEL_MODERATE':
      return '$$';
    case 'PRICE_LEVEL_EXPENSIVE':
      return '$$$';
    case 'PRICE_LEVEL_VERY_EXPENSIVE':
      return '$$$$';
    default:
      return '$$';
  }
}

function photoUrl(photoName: string | undefined, apiKey: string): string {
  if (!photoName) {
    return 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80';
  }
  return `https://places.googleapis.com/v1/${photoName}/media?maxWidthPx=1200&key=${apiKey}`;
}

async function fetchFromGooglePlaces(params: TravelServiceParams) {
  const fieldMask = [
    'places.id',
    'places.displayName',
    'places.formattedAddress',
    'places.rating',
    'places.userRatingCount',
    'places.priceLevel',
    'places.photos',
    'places.regularOpeningHours',
    'places.primaryTypeDisplayName',
  ].join(',');

  const res = await fetch('https://places.googleapis.com/v1/places:searchText', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': PLACES_API_KEY,
      'X-Goog-FieldMask': fieldMask,
    },
    body: JSON.stringify({
      textQuery: `best restaurants in ${params.destination}`,
      maxResultCount: 8,
    }),
  });

  if (!res.ok) {
    throw new Error(`Google Places API error: ${res.status} ${await res.text()}`);
  }

  const data = await res.json();
  const places: any[] = data.places || [];
  const city = params.destination.split(',')[0].trim();

  return places.map((place, i) => ({
    id: place.id || `rest-${i}`,
    name: place.displayName?.text || `Restaurant in ${city}`,
    cuisine: place.primaryTypeDisplayName?.text || 'Local Cuisine',
    photo: photoUrl(place.photos?.[0]?.name, PLACES_API_KEY),
    gallery: (place.photos || []).slice(0, 3).map((p: any) => photoUrl(p.name, PLACES_API_KEY)),
    rating: place.rating ?? 4.5,
    reviewsCount: place.userRatingCount ?? 0,
    priceRange: priceLevelToRange(place.priceLevel),
    distanceFromCenterKm: null,
    neighborhood: place.formattedAddress?.split(',')[1]?.trim() || city,
    availability: 'Reservation required' as const,
    specialties: [],
    features: [],
    bookingUrl: createRestaurantReservationLink(place.displayName?.text || 'Restaurant', city),
    provider: 'TripAdvisor' as const,
    address: place.formattedAddress || '',
    openingHours: place.regularOpeningHours?.weekdayDescriptions?.[0] || 'See listing for hours',
  }));
}

export async function fetchRestaurants(params: TravelServiceParams) {
  const key = TTLCache.keyFrom({ dest: params.destination, days: params.durationDays, type: 'restaurants' });
  const cached = cache.get(key);
  if (cached) return cached;

  let result;
  if (PLACES_API_KEY) {
    try {
      result = await fetchFromGooglePlaces(params);
      if (!result.length) result = generateMockRestaurants(params);
    } catch (err) {
      console.error('[restaurants] Google Places lookup failed, falling back to mock data:', err);
      result = generateMockRestaurants(params);
    }
  } else {
    result = generateMockRestaurants(params);
  }

  cache.set(key, result);
  return result;
}

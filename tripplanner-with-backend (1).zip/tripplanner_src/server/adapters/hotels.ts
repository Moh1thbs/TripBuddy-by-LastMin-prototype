import { generateMockHotels, createHotelBookingDeepLink, TravelServiceParams } from '../../shared/mockTravelData.js';
import { TTLCache } from '../lib/cache.js';

const cache = new TTLCache<any[]>(10 * 60 * 1000); // 10 minutes
const PLACES_API_KEY = process.env.GOOGLE_PLACES_API_KEY || '';

function priceLevelToRange(level?: string): '$' | '$$' | '$$$' | '$$$$' {
  switch (level) {
    case 'PRICE_LEVEL_FREE':
    case 'PRICE_LEVEL_INEXPENSIVE':
      return '$';
    case 'PRICE_LEVEL_MODERATE':
      return '$$';
    case 'PRICE_LEVEL_EXPENSIVE':
      return '$$$';
    case 'PRICE_LEVEL_VERY_EXPENSIVE':
      return '$$$$';
    default:
      return '$$';
  }
}

function photoUrl(photoName: string | undefined, apiKey: string): string {
  if (!photoName) {
    return 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80';
  }
  // Places API (New) media endpoint
  return `https://places.googleapis.com/v1/${photoName}/media?maxWidthPx=1200&key=${apiKey}`;
}

async function fetchFromGooglePlaces(params: TravelServiceParams) {
  const fieldMask = [
    'places.id',
    'places.displayName',
    'places.formattedAddress',
    'places.rating',
    'places.userRatingCount',
    'places.priceLevel',
    'places.photos',
    'places.googleMapsUri',
    'places.location',
  ].join(',');

  const res = await fetch('https://places.googleapis.com/v1/places:searchText', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Goog-Api-Key': PLACES_API_KEY,
      'X-Goog-FieldMask': fieldMask,
    },
    body: JSON.stringify({
      textQuery: `hotels in ${params.destination}`,
      maxResultCount: 8,
    }),
  });

  if (!res.ok) {
    throw new Error(`Google Places API error: ${res.status} ${await res.text()}`);
  }

  const data = await res.json();
  const places: any[] = data.places || [];
  const city = params.destination.split(',')[0].trim();

  return places.map((place, i) => ({
    id: place.id || `hotel-${i}`,
    name: place.displayName?.text || `Hotel in ${city}`,
    tagline: place.formattedAddress || `Stay in ${city}`,
    photo: photoUrl(place.photos?.[0]?.name, PLACES_API_KEY),
    gallery: (place.photos || []).slice(0, 3).map((p: any) => photoUrl(p.name, PLACES_API_KEY)),
    rating: place.rating ?? 4.5,
    reviewsCount: place.userRatingCount ?? 0,
    pricePerNight: null, // Places API doesn't expose nightly rates; left for a booking-provider adapter to fill in
    priceRange: priceLevelToRange(place.priceLevel),
    distanceFromCenterKm: null,
    neighborhood: place.formattedAddress?.split(',')[1]?.trim() || city,
    availability: 'Available' as const,
    amenities: [],
    highlights: [],
    bookingUrl: createHotelBookingDeepLink(place.displayName?.text || 'Hotel', city, params.startDate, params.durationDays),
    provider: 'Direct' as const,
    address: place.formattedAddress || '',
  }));
}

export async function fetchHotels(params: TravelServiceParams) {
  const key = TTLCache.keyFrom({ dest: params.destination, days: params.durationDays, type: 'hotels' });
  const cached = cache.get(key);
  if (cached) return cached;

  let result;
  if (PLACES_API_KEY) {
    try {
      result = await fetchFromGooglePlaces(params);
      if (!result.length) result = generateMockHotels(params);
    } catch (err) {
      console.error('[hotels] Google Places lookup failed, falling back to mock data:', err);
      result = generateMockHotels(params);
    }
  } else {
    result = generateMockHotels(params);
  }

  cache.set(key, result);
  return result;
}

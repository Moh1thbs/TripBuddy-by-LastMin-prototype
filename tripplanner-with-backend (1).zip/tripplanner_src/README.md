# TripPlanner

A modern, minimal, continuous web application for designing trips, discovering personalized recommendations (hotels, restaurants, and transport), experiencing live destination ambiance, and tracking expenses with Firestore persistence.

---

## Features

1. **Continuous Seamless UI**
   - No jarring page reloads; screens swap with smooth transitions.
   - Light and airy travel palette with teal/emerald accents, readable typography (Inter & Plus Jakarta Sans), rounded cards, and frosted-glass blur overlays.

2. **Screen 1: Authentication & User Accounts**
   - Email & password sign-up and login with clear error messaging.
   - "Continue with Google" popup authentication.
   - One-click "Instant Demo" option for immediate testing.
   - Persistent user sessions and profile sync in Firestore (`users/{uid}`).

3. **Screen 2: Trip Details Form**
   - Destination search with autocomplete for global cities (Paris, Tokyo, Rome, New York, Barcelona, etc.).
   - Exact departure date picker with auto-calculated travel season (Spring, Summer, Autumn, Winter).
   - Stay duration selector with quick presets (3d weekend, 5d city break, 7d week, 14d fortnight).
   - Selectable transport mode cards (Flight, Train, Bus, Car, Cruise) with iconography.
   - Validated inputs and automatic trip saving to Firestore.

4. **Screen 3: Recommendations Dashboard**
   - Three distinct categories: **Hotels**, **Restaurants**, and **Travel/Transport**.
   - Cards display photos, ratings, price tiers, distance from center, live availability tags, and highlights.
   - Swappable backend service layer (`src/services/travelService.ts`) with clear hook points for live API keys (Booking.com, Google Places, TripAdvisor, Skyscanner, OpenTable).
   - Detail popup with photo carousel, amenities, and direct deep-linking ("Book / Reserve") with prefilled dates and destination.
   - Filters for price, minimum rating, and live availability, plus sorting options (Recommended, Rating, Price, Distance).

5. **Full-Screen Background Slideshow (Screens 2 & 3)**
   - Preloaded high-resolution destination spots.
   - Ken Burns zoom and slow crossfade every 6 seconds.
   - Vignette and frosted-glass overlay ensuring crisp legibility of all content.
   - Subtle controls for play/pause and manual slide browsing.

6. **Expense Tracker**
   - Manual expense logging: Amount, Category (Stay, Food, Transport, Activities, Shopping, Other), Date, Note, and Currency.
   - Real-time Firestore synchronization using `onSnapshot`.
   - Trip budget setting and dynamic remaining-balance progress bar (with warning state when near or over budget).
   - Interactive SVG Donut chart displaying percentage distribution.
   - Search by note/description and category filtering.
   - Edit and delete records with confirmation.

---

## Technical Setup & Deployment

### 1. Environment Variables (`.env`)

Create a `.env` file in the root directory:

```env
# Firebase Web Configuration (frontend — used directly in the browser)
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="your-sender-id"
VITE_FIREBASE_APP_ID="your-app-id"

# Live Travel API (backend only — never prefixed with VITE_, so it's never
# bundled into client JS. Optional: rich mock data is served automatically
# when this is unset.)
GOOGLE_PLACES_API_KEY="your-google-places-api-key"

# Backend server
PORT="8787"
ALLOWED_ORIGIN=""   # lock CORS to your deployed frontend's origin in production

# Only set this if the frontend is deployed separately from the backend.
VITE_API_BASE_URL=""
```

### 2. Backend API Server

`server/` is a small Express app that fronts hotel, restaurant, and transport
recommendations behind three endpoints:

- `GET /api/hotels?destination=&startDate=&durationDays=&transportMode=`
- `GET /api/restaurants?destination=&startDate=&durationDays=&transportMode=`
- `GET /api/transport?destination=&startDate=&durationDays=&transportMode=`
- `GET /api/health`

Hotels and restaurants call the Google Places API (New) server-side when
`GOOGLE_PLACES_API_KEY` is set, cache each response for 10 minutes, and fall
back to realistic mock data automatically if the key is missing or the call
fails — so the app always works, with or without a key. Transport is a
mock-backed adapter with a clear plug-in point (`server/adapters/transport.ts`)
for a real flights/rail provider (Amadeus, Skyscanner, etc.) later. All
endpoints are rate-limited (60 req/min/IP) and sit behind `helmet` + `cors`.

The frontend's `src/services/travelService.ts` calls these endpoints (via a
same-origin `/api/...` path, or `VITE_API_BASE_URL` if the backend is hosted
elsewhere) and itself falls back to mock data if the backend can't be
reached, so the UI never dead-ends.

### 3. Firestore Security Rules

Deploy the included `firestore.rules` file to restrict data access to authenticated owners:

```rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /users/{userId}/trips/{tripId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;

      match /expenses/{expenseId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

Deploy using Firebase CLI:
```bash
firebase deploy --only firestore:rules
```

### 4. Running Locally

```bash
# Install dependencies
npm install

# Terminal 1: run the API backend (port 8787 by default)
npm run server

# Terminal 2: run the Vite dev server
npm run dev

# Open http://localhost:3000 — /api/* requests are proxied to the backend
```

### 5. Deploying

The backend serves the built frontend itself in production, so you can ship
both as a single service (e.g. one Cloud Run container):

```bash
# 1. Build the production frontend bundle
npm run build

# 2. Start the Express server in production mode — it serves the API
#    *and* the built frontend (dist/) from one process/port
npm run start
```

Set `GOOGLE_PLACES_API_KEY`, `ALLOWED_ORIGIN`, and the `VITE_FIREBASE_*`
variables as environment variables/secrets on your host (Cloud Run, Fly.io,
a VM, etc.) — `PORT` is usually injected automatically by the platform.

Alternatively, deploy the frontend to Firebase Hosting and the backend
elsewhere (Cloud Run, Render, etc.), pointing the frontend at it via
`VITE_API_BASE_URL`:

```bash
firebase login
firebase init hosting
# - Public directory: dist
# - Single-page app (SPA): Yes
firebase deploy --only hosting
```

---

## Folder Structure

```
├── firestore.rules               # Firestore security rules per user
├── firebase-applet-config.json   # Provisioned Firebase app configuration
├── server/                       # Express backend (API + static serving in prod)
│   ├── index.ts                  # App setup, security middleware, listen
│   ├── routes/travel.ts          # /api/hotels, /api/restaurants, /api/transport
│   ├── adapters/                 # Google Places-backed + mock-fallback adapters
│   │   ├── hotels.ts
│   │   ├── restaurants.ts
│   │   └── transport.ts
│   └── lib/
│       ├── cache.ts              # In-memory TTL response cache
│       └── rateLimiter.ts        # Per-IP rate limiting
├── shared/
│   └── mockTravelData.ts         # Mock data generators used by both frontend & backend
├── src/
│   ├── components/
│   │   ├── AuthModal.tsx         # Screen 1: Email/Password + Google Auth
│   │   ├── BackgroundSlideshow.tsx# Ken Burns ambient background slideshow
│   │   ├── DetailModal.tsx       # Booking & reservation detail popup
│   │   ├── ExpenseTracker.tsx    # Budget, donut chart, and Firestore expenses
│   │   ├── Header.tsx            # Continuous navigation bar
│   │   ├── RecommendationsDashboard.tsx # Screen 3: Hotels, Dining & Transport
│   │   ├── SavedTripsModal.tsx   # Saved trips drawer & switcher
│   │   ├── SetupGuideModal.tsx   # In-app setup & API documentation
│   │   └── TripForm.tsx          # Screen 2: Trip details & autocomplete
│   ├── data/
│   │   └── destinations.ts       # Curated destination database & photo sets
│   ├── services/
│   │   ├── firestoreService.ts   # Firestore CRUD and onSnapshot subscriptions
│   │   └── travelService.ts      # Calls the backend API, with mock-data fallback
│   ├── types/
│   │   └── index.ts              # Core TypeScript interfaces
│   ├── App.tsx                   # Main continuous UI controller
│   ├── firebase.ts               # Firebase initialization and auth helpers
│   ├── index.css                 # Tailwind CSS styles & animations
│   └── main.tsx                  # React entry point
└── vite.config.ts                # Includes /api dev proxy to the backend
```

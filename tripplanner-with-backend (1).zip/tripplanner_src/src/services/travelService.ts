import {
  HotelRecommendation,
  RestaurantRecommendation,
  TransportOption,
  TransportMode,
} from '../types';
import {
  generateMockHotels,
  generateMockRestaurants,
  generateMockTransport,
  createHotelBookingDeepLink,
  createRestaurantReservationLink,
  createTransportDeepLink,
} from '../../shared/mockTravelData';

/**
 * =========================================================================
 * TRAVEL API SERVICE LAYER
 * =========================================================================
 * The heavy lifting (calling Google Places, caching, hiding API keys) now
 * happens server-side in `server/adapters/*`. This module just calls the
 * backend's `/api/hotels`, `/api/restaurants`, `/api/transport` endpoints.
 *
 * If the backend is unreachable (not running, network hiccup, etc.) each
 * adapter falls back to the same rich mock data used during development,
 * so the UI never dead-ends.
 *
 * `VITE_API_BASE_URL` lets you point the frontend at a backend hosted
 * elsewhere (e.g. a separate Cloud Run service). Leave it unset to use
 * same-origin requests — the default, and what the Vite dev proxy and the
 * production Express server (which serves both the API and the built
 * frontend) both expect.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '';

export { createHotelBookingDeepLink, createRestaurantReservationLink, createTransportDeepLink };

export interface TravelServiceParams {
  destination: string;
  startDate: string;
  durationDays: number;
  transportMode: TransportMode;
}

function buildQuery(params: TravelServiceParams): string {
  return new URLSearchParams({
    destination: params.destination,
    startDate: params.startDate,
    durationDays: String(params.durationDays),
    transportMode: params.transportMode,
  }).toString();
}

async function getJson<T>(path: string, params: TravelServiceParams): Promise<T> {
  const res = await fetch(`${API_BASE_URL}/api/${path}?${buildQuery(params)}`);
  if (!res.ok) {
    throw new Error(`Backend request to /api/${path} failed with status ${res.status}`);
  }
  return res.json();
}

// -------------------------------------------------------------
// ADAPTER INTERFACES
// -------------------------------------------------------------
export interface IHotelAdapter {
  fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]>;
}

export interface IRestaurantAdapter {
  fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]>;
}

export interface ITransportAdapter {
  fetchTransport(params: TravelServiceParams): Promise<TransportOption[]>;
}

// -------------------------------------------------------------
// BACKEND-BACKED ADAPTERS (default)
// -------------------------------------------------------------
export class BackendHotelAdapter implements IHotelAdapter {
  async fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    try {
      return await getJson<HotelRecommendation[]>('hotels', params);
    } catch (err) {
      console.warn('[travelService] Falling back to mock hotels — backend unreachable:', err);
      return generateMockHotels(params);
    }
  }
}

export class BackendRestaurantAdapter implements IRestaurantAdapter {
  async fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    try {
      return await getJson<RestaurantRecommendation[]>('restaurants', params);
    } catch (err) {
      console.warn('[travelService] Falling back to mock restaurants — backend unreachable:', err);
      return generateMockRestaurants(params);
    }
  }
}

export class BackendTransportAdapter implements ITransportAdapter {
  async fetchTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    try {
      return await getJson<TransportOption[]>('transport', params);
    } catch (err) {
      console.warn('[travelService] Falling back to mock transport — backend unreachable:', err);
      return generateMockTransport(params);
    }
  }
}

// -------------------------------------------------------------
// MOCK-ONLY ADAPTERS (useful for offline dev or Storybook-style previews)
// -------------------------------------------------------------
export class MockHotelAdapter implements IHotelAdapter {
  async fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    await new Promise((resolve) => setTimeout(resolve, 600));
    return generateMockHotels(params);
  }
}

export class MockRestaurantAdapter implements IRestaurantAdapter {
  async fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    await new Promise((resolve) => setTimeout(resolve, 650));
    return generateMockRestaurants(params);
  }
}

export class MockTransportAdapter implements ITransportAdapter {
  async fetchTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    await new Promise((resolve) => setTimeout(resolve, 550));
    return generateMockTransport(params);
  }
}

// -------------------------------------------------------------
// CENTRAL REPOSITORY / SERVICE COORDINATOR
// -------------------------------------------------------------
class TravelService {
  private hotelAdapter: IHotelAdapter = new BackendHotelAdapter();
  private restaurantAdapter: IRestaurantAdapter = new BackendRestaurantAdapter();
  private transportAdapter: ITransportAdapter = new BackendTransportAdapter();

  // Allow dynamic plugging of custom adapters (e.g. swap in MockHotelAdapter
  // for an offline demo, or a different provider entirely).
  public setHotelAdapter(adapter: IHotelAdapter) {
    this.hotelAdapter = adapter;
  }

  public setRestaurantAdapter(adapter: IRestaurantAdapter) {
    this.restaurantAdapter = adapter;
  }

  public setTransportAdapter(adapter: ITransportAdapter) {
    this.transportAdapter = adapter;
  }

  public async getHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    return this.hotelAdapter.fetchHotels(params);
  }

  public async getRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    return this.restaurantAdapter.fetchRestaurants(params);
  }

  public async getTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    return this.transportAdapter.fetchTransport(params);
  }
}

export const travelService = new TravelService();

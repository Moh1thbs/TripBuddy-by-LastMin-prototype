# TripPlanner

A modern, minimal, continuous web application for designing trips, discovering personalized recommendations (hotels, restaurants, and transport), experiencing live destination ambiance, and tracking expenses with Firestore persistence.

---

## Features

1. **Continuous Seamless UI**
   - No jarring page reloads; screens swap with smooth transitions.
   - Light and airy travel palette with teal/emerald accents, readable typography (Inter & Plus Jakarta Sans), rounded cards, and frosted-glass blur overlays.

2. **Screen 1: Authentication & User Accounts**
   - Email & password sign-up and login with clear error messaging.
   - "Continue with Google" popup authentication.
   - One-click "Instant Demo" option for immediate testing.
   - Persistent user sessions and profile sync in Firestore (`users/{uid}`).

3. **Screen 2: Trip Details Form**
   - Destination search with autocomplete for global cities (Paris, Tokyo, Rome, New York, Barcelona, etc.).
   - Exact departure date picker with auto-calculated travel season (Spring, Summer, Autumn, Winter).
   - Stay duration selector with quick presets (3d weekend, 5d city break, 7d week, 14d fortnight).
   - Selectable transport mode cards (Flight, Train, Bus, Car, Cruise) with iconography.
   - Validated inputs and automatic trip saving to Firestore.

4. **Screen 3: Recommendations Dashboard**
   - Three distinct categories: **Hotels**, **Restaurants**, and **Travel/Transport**.
   - Cards display photos, ratings, price tiers, distance from center, live availability tags, and highlights.
   - Swappable backend service layer (`src/services/travelService.ts`) with clear hook points for live API keys (Booking.com, Google Places, TripAdvisor, Skyscanner, OpenTable).
   - Detail popup with photo carousel, amenities, and direct deep-linking ("Book / Reserve") with prefilled dates and destination.
   - Filters for price, minimum rating, and live availability, plus sorting options (Recommended, Rating, Price, Distance).

5. **Full-Screen Background Slideshow (Screens 2 & 3)**
   - Preloaded high-resolution destination spots.
   - Ken Burns zoom and slow crossfade every 6 seconds.
   - Vignette and frosted-glass overlay ensuring crisp legibility of all content.
   - Subtle controls for play/pause and manual slide browsing.

6. **Expense Tracker**
   - Manual expense logging: Amount, Category (Stay, Food, Transport, Activities, Shopping, Other), Date, Note, and Currency.
   - Real-time Firestore synchronization using `onSnapshot`.
   - Trip budget setting and dynamic remaining-balance progress bar (with warning state when near or over budget).
   - Interactive SVG Donut chart displaying percentage distribution.
   - Search by note/description and category filtering.
   - Edit and delete records with confirmation.

---

## Technical Setup & Deployment

### 1. Environment Variables (`.env`)

Create a `.env` file in the root directory:

```env
# Firebase Web Configuration
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="your-sender-id"
VITE_FIREBASE_APP_ID="your-app-id"

# Live Third-Party Travel APIs (Optional - realistic mock adapters active by default)
VITE_BOOKING_API_KEY="your_rapidapi_booking_key"
VITE_GOOGLE_PLACES_API_KEY="your_google_places_key"
VITE_SKYSCANNER_API_KEY="your_skyscanner_api_key"
```

### 2. Firestore Security Rules

Deploy the included `firestore.rules` file to restrict data access to authenticated owners:

```rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /users/{userId}/trips/{tripId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;

      match /expenses/{expenseId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}
```

Deploy using Firebase CLI:
```bash
firebase deploy --only firestore:rules
```

### 3. Running Locally

```bash
# Install dependencies
npm install

# Run Vite dev server
npm run dev

# Open http://localhost:3000 in your browser
```

### 4. Deploying on Firebase Hosting

```bash
# 1. Build the production application
npm run build

# 2. Login and initialize hosting
firebase login
firebase init hosting
# - Public directory: dist
# - Single-page app (SPA): Yes
# - Automatic builds with GitHub: Optional

# 3. Deploy
firebase deploy --only hosting
```

---

## Folder Structure

```
├── firestore.rules               # Firestore security rules per user
├── firebase-applet-config.json   # Provisioned Firebase app configuration
├── src/
│   ├── components/
│   │   ├── AuthModal.tsx         # Screen 1: Email/Password + Google Auth
│   │   ├── BackgroundSlideshow.tsx# Ken Burns ambient background slideshow
│   │   ├── DetailModal.tsx       # Booking & reservation detail popup
│   │   ├── ExpenseTracker.tsx    # Budget, donut chart, and Firestore expenses
│   │   ├── Header.tsx            # Continuous navigation bar
│   │   ├── RecommendationsDashboard.tsx # Screen 3: Hotels, Dining & Transport
│   │   ├── SavedTripsModal.tsx   # Saved trips drawer & switcher
│   │   ├── SetupGuideModal.tsx   # In-app setup & API documentation
│   │   └── TripForm.tsx          # Screen 2: Trip details & autocomplete
│   ├── data/
│   │   └── destinations.ts       # Curated destination database & photo sets
│   ├── services/
│   │   ├── firestoreService.ts   # Firestore CRUD and onSnapshot subscriptions
│   │   └── travelService.ts      # Swappable adapter layer for 3rd-party APIs
│   ├── types/
│   │   └── index.ts              # Core TypeScript interfaces
│   ├── App.tsx                   # Main continuous UI controller
│   ├── firebase.ts               # Firebase initialization and auth helpers
│   ├── index.css                 # Tailwind CSS styles & animations
│   └── main.tsx                  # React entry point
└── vite.config.ts
```

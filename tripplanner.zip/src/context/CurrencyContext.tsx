import React, { createContext, useContext, useState, useEffect } from 'react';

export type CurrencyCode = 'USD' | 'INR' | 'JPY' | 'EUR' | 'GBP' | 'AUD' | 'CAD' | 'AED' | 'SGD';

export interface CurrencyInfo {
  code: CurrencyCode;
  name: string;
  symbol: string;
  rateAgainstUSD: number;
  flag: string;
  decimals: number;
}

export const CURRENCY_MAP: Record<CurrencyCode, CurrencyInfo> = {
  USD: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    rateAgainstUSD: 1.0,
    flag: '🇺🇸',
    decimals: 2,
  },
  INR: {
    code: 'INR',
    name: 'Indian Rupee',
    symbol: '₹',
    rateAgainstUSD: 83.5,
    flag: '🇮🇳',
    decimals: 0,
  },
  JPY: {
    code: 'JPY',
    name: 'Japanese Yen',
    symbol: '¥',
    rateAgainstUSD: 155.0,
    flag: '🇯🇵',
    decimals: 0,
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    rateAgainstUSD: 0.92,
    flag: '🇪🇺',
    decimals: 2,
  },
  GBP: {
    code: 'GBP',
    name: 'British Pound',
    symbol: '£',
    rateAgainstUSD: 0.79,
    flag: '🇬🇧',
    decimals: 2,
  },
  AUD: {
    code: 'AUD',
    name: 'Australian Dollar',
    symbol: 'A$',
    rateAgainstUSD: 1.52,
    flag: '🇦🇺',
    decimals: 2,
  },
  CAD: {
    code: 'CAD',
    name: 'Canadian Dollar',
    symbol: 'C$',
    rateAgainstUSD: 1.36,
    flag: '🇨🇦',
    decimals: 2,
  },
  AED: {
    code: 'AED',
    name: 'UAE Dirham',
    symbol: 'د.إ',
    rateAgainstUSD: 3.67,
    flag: '🇦🇪',
    decimals: 2,
  },
  SGD: {
    code: 'SGD',
    name: 'Singapore Dollar',
    symbol: 'S$',
    rateAgainstUSD: 1.34,
    flag: '🇸🇬',
    decimals: 2,
  },
};

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (code: CurrencyCode) => void;
  currencyInfo: CurrencyInfo;
  availableCurrencies: CurrencyInfo[];
  convertFromUSD: (usdAmount: number) => number;
  convertToUSD: (amount: number, fromCurrency: CurrencyCode) => number;
  convertBetween: (amount: number, from: CurrencyCode, to: CurrencyCode) => number;
  formatPriceFromUSD: (usdAmount: number, overrideCode?: CurrencyCode) => string;
  formatAmount: (amount: number, currencyCode?: CurrencyCode) => string;
}

const CurrencyContext = createContext<CurrencyContextType | null>(null);

const STORAGE_KEY = 'tripplanner_preferred_currency';

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currency, setCurrencyState] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem(STORAGE_KEY) as CurrencyCode;
    return saved && CURRENCY_MAP[saved] ? saved : 'USD';
  });

  const [rates, setRates] = useState<Record<CurrencyCode, number>>({
    USD: 1.0,
    INR: 83.5,
    JPY: 155.0,
    EUR: 0.92,
    GBP: 0.79,
    AUD: 1.52,
    CAD: 1.36,
    AED: 3.67,
    SGD: 1.34,
  });

  // Attempt to fetch fresh exchange rates in the background with zero lag fallback
  useEffect(() => {
    let isMounted = true;
    fetch('https://open.er-api.com/v6/latest/USD')
      .then((res) => res.json())
      .then((data) => {
        if (isMounted && data && data.rates) {
          setRates((prev) => ({
            USD: 1.0,
            INR: data.rates.INR || prev.INR,
            JPY: data.rates.JPY || prev.JPY,
            EUR: data.rates.EUR || prev.EUR,
            GBP: data.rates.GBP || prev.GBP,
            AUD: data.rates.AUD || prev.AUD,
            CAD: data.rates.CAD || prev.CAD,
            AED: data.rates.AED || prev.AED,
            SGD: data.rates.SGD || prev.SGD,
          }));
        }
      })
      .catch(() => {
        // use fallback static rates
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const setCurrency = (code: CurrencyCode) => {
    if (CURRENCY_MAP[code]) {
      setCurrencyState(code);
      localStorage.setItem(STORAGE_KEY, code);
    }
  };

  const currentRate = rates[currency] || CURRENCY_MAP[currency].rateAgainstUSD;

  const convertFromUSD = (usdAmount: number): number => {
    return usdAmount * currentRate;
  };

  const convertToUSD = (amount: number, fromCurrency: CurrencyCode): number => {
    const fromRate = rates[fromCurrency] || CURRENCY_MAP[fromCurrency]?.rateAgainstUSD || 1.0;
    return amount / fromRate;
  };

  const convertBetween = (amount: number, from: CurrencyCode, to: CurrencyCode): number => {
    const inUSD = convertToUSD(amount, from);
    const toRate = rates[to] || CURRENCY_MAP[to]?.rateAgainstUSD || 1.0;
    return inUSD * toRate;
  };

  const formatPriceFromUSD = (usdAmount: number, overrideCode?: CurrencyCode): string => {
    const targetCode = overrideCode || currency;
    const targetInfo = CURRENCY_MAP[targetCode] || CURRENCY_MAP.USD;
    const targetRate = rates[targetCode] || targetInfo.rateAgainstUSD;
    const converted = usdAmount * targetRate;

    return formatAmount(converted, targetCode);
  };

  const formatAmount = (amount: number, currencyCode?: CurrencyCode): string => {
    const code = currencyCode || currency;
    const info = CURRENCY_MAP[code] || CURRENCY_MAP.USD;

    const formattedNum = amount.toLocaleString(undefined, {
      minimumFractionDigits: info.decimals,
      maximumFractionDigits: info.decimals,
    });

    return `${info.symbol}${formattedNum}`;
  };

  const currencyInfo: CurrencyInfo = {
    ...CURRENCY_MAP[currency],
    rateAgainstUSD: currentRate,
  };

  const availableCurrencies = Object.values(CURRENCY_MAP);

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        setCurrency,
        currencyInfo,
        availableCurrencies,
        convertFromUSD,
        convertToUSD,
        convertBetween,
        formatPriceFromUSD,
        formatAmount,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = (): CurrencyContextType => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
};

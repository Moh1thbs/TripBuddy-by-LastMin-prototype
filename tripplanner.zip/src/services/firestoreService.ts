import {
  db,
  doc,
  setDoc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
  onSnapshot,
  addDoc,
  deleteDoc,
  updateDoc,
  orderBy,
  User,
} from '../firebase';
import { Trip, Expense, UserProfile } from '../types';

/**
 * Creates or updates user profile document in Firestore
 */
export async function syncUserProfile(user: User): Promise<UserProfile> {
  const userRef = doc(db, 'users', user.uid);
  const snap = await getDoc(userRef);

  if (!snap.exists()) {
    const profile: UserProfile = {
      uid: user.uid,
      email: user.email,
      displayName: user.displayName || user.email?.split('@')[0] || 'Traveler',
      photoURL: user.photoURL,
      createdAt: Date.now(),
    };
    await setDoc(userRef, profile);
    return profile;
  }

  const data = snap.data() as UserProfile;
  return data;
}

/**
 * Save a new trip to Firestore under the user's account
 */
export async function saveTrip(trip: Omit<Trip, 'id'>): Promise<string> {
  const tripsRef = collection(db, 'users', trip.userId, 'trips');
  const docRef = await addDoc(tripsRef, {
    ...trip,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  });
  return docRef.id;
}

/**
 * Update an existing trip (e.g. updating budget or details)
 */
export async function updateTrip(userId: string, tripId: string, updates: Partial<Trip>): Promise<void> {
  const tripRef = doc(db, 'users', userId, 'trips', tripId);
  await updateDoc(tripRef, {
    ...updates,
    updatedAt: Date.now(),
  });
}

/**
 * Fetch all saved trips for a user
 */
export async function getUserTrips(userId: string): Promise<Trip[]> {
  try {
    const tripsRef = collection(db, 'users', userId, 'trips');
    const q = query(tripsRef, orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...(docSnap.data() as Omit<Trip, 'id'>),
    }));
  } catch (error) {
    console.error('Error fetching trips:', error);
    return [];
  }
}

/**
 * Subscribe in real-time to user's trips
 */
export function subscribeToUserTrips(userId: string, onUpdate: (trips: Trip[]) => void): () => void {
  const tripsRef = collection(db, 'users', userId, 'trips');
  const q = query(tripsRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const trips = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Trip, 'id'>),
      }));
      onUpdate(trips);
    },
    (err) => {
      console.warn('Realtime trips listener error, falling back:', err);
    }
  );
}

/**
 * Add a new expense for a trip
 */
export async function addExpense(
  userId: string,
  tripId: string,
  expense: Omit<Expense, 'id' | 'createdAt'>
): Promise<string> {
  const expensesRef = collection(db, 'users', userId, 'trips', tripId, 'expenses');
  const docRef = await addDoc(expensesRef, {
    ...expense,
    createdAt: Date.now(),
  });
  return docRef.id;
}

/**
 * Update an expense
 */
export async function updateExpense(
  userId: string,
  tripId: string,
  expenseId: string,
  updates: Partial<Omit<Expense, 'id' | 'tripId' | 'userId' | 'createdAt'>>
): Promise<void> {
  const expenseRef = doc(db, 'users', userId, 'trips', tripId, 'expenses', expenseId);
  await updateDoc(expenseRef, updates);
}

/**
 * Delete an expense
 */
export async function deleteExpense(userId: string, tripId: string, expenseId: string): Promise<void> {
  const expenseRef = doc(db, 'users', userId, 'trips', tripId, 'expenses', expenseId);
  await deleteDoc(expenseRef);
}

/**
 * Subscribe in real-time to expenses for a trip
 */
export function subscribeToTripExpenses(
  userId: string,
  tripId: string,
  onUpdate: (expenses: Expense[]) => void
): () => void {
  const expensesRef = collection(db, 'users', userId, 'trips', tripId, 'expenses');
  const q = query(expensesRef, orderBy('date', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const expenses = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...(docSnap.data() as Omit<Expense, 'id'>),
      }));
      onUpdate(expenses);
    },
    (err) => {
      console.warn('Realtime expenses listener error:', err);
    }
  );
}

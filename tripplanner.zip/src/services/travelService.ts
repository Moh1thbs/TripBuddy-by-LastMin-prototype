import {
  HotelRecommendation,
  RestaurantRecommendation,
  TransportOption,
  TransportMode,
} from '../types';

/**
 * =========================================================================
 * TRAVEL API SERVICE LAYER & SWAPPABLE ADAPTERS
 * =========================================================================
 * This service provides an abstracted adapter interface for:
 * 1. Hotels (e.g., Booking.com, Google Places, Expedia)
 * 2. Restaurants (e.g., Google Places, TripAdvisor, OpenTable)
 * 3. Transport (e.g., Skyscanner, Google Flights, Trainline, Omio)
 *
 * TO CONNECT LIVE API KEYS:
 * 1. Supply environment variables in your .env:
 *    - VITE_BOOKING_API_KEY="your_rapidapi_booking_key"
 *    - VITE_GOOGLE_PLACES_API_KEY="your_google_places_key"
 *    - VITE_SKYSCANNER_API_KEY="your_skyscanner_api_key"
 * 2. Switch the active adapter below or toggle useLiveApi = true.
 */

export interface TravelServiceParams {
  destination: string;
  startDate: string;
  durationDays: number;
  transportMode: TransportMode;
}

// -------------------------------------------------------------
// Booking URLs & Deep Link Generators
// -------------------------------------------------------------
export function createHotelBookingDeepLink(hotelName: string, destination: string, checkIn: string, durationDays: number): string {
  try {
    const d = new Date(checkIn);
    const checkout = new Date(d.getTime() + durationDays * 24 * 60 * 60 * 1000);
    const checkinStr = checkIn;
    const checkoutStr = checkout.toISOString().split('T')[0];

    const query = encodeURIComponent(`${hotelName} ${destination}`);
    // Deep link to Booking.com search with prefilled location and dates
    return `https://www.booking.com/searchresults.html?ss=${query}&checkin=${checkinStr}&checkout=${checkoutStr}&group_adults=2&no_rooms=1&group_children=0`;
  } catch {
    return `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(destination)}`;
  }
}

export function createRestaurantReservationLink(restaurantName: string, destination: string): string {
  const query = encodeURIComponent(`${restaurantName} ${destination}`);
  return `https://www.opentable.com/s?term=${query}`;
}

export function createTransportDeepLink(mode: TransportMode, destination: string, date: string): string {
  const query = encodeURIComponent(destination);
  switch (mode) {
    case 'Flight':
      return `https://www.google.com/travel/flights?q=flights+to+${query}+on+${date}`;
    case 'Train':
      return `https://www.thetrainline.com/search?to=${query}`;
    case 'Bus':
      return `https://www.omio.com/search?destination=${query}`;
    case 'Car':
      return `https://www.rentalcars.com/search-results?location=${query}`;
    case 'Cruise':
      return `https://www.cruisecritic.com/search/?q=${query}`;
    default:
      return `https://www.google.com/travel?q=${query}`;
  }
}

// -------------------------------------------------------------
// ADAPTER INTERFACES
// -------------------------------------------------------------
export interface IHotelAdapter {
  fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]>;
}

export interface IRestaurantAdapter {
  fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]>;
}

export interface ITransportAdapter {
  fetchTransport(params: TravelServiceParams): Promise<TransportOption[]>;
}

// -------------------------------------------------------------
// LIVE ADAPTER STUBS (Marked with comments for direct drop-in)
// -------------------------------------------------------------
export class LiveBookingDotComAdapter implements IHotelAdapter {
  private apiKey = import.meta.env.VITE_BOOKING_API_KEY || '';

  async fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    if (!this.apiKey) {
      // Fallback seamlessly to mock if API key isn't populated
      return new MockHotelAdapter().fetchHotels(params);
    }

    // Example RapidAPI Booking.com call:
    /*
    const response = await fetch(`https://booking-com.p.rapidapi.com/v1/hotels/searchFilters?name=${encodeURIComponent(params.destination)}`, {
      headers: {
        'x-rapidapi-key': this.apiKey,
        'x-rapidapi-host': 'booking-com.p.rapidapi.com'
      }
    });
    const data = await response.json();
    return transformBookingResponse(data);
    */
    return new MockHotelAdapter().fetchHotels(params);
  }
}

export class LiveGooglePlacesRestaurantAdapter implements IRestaurantAdapter {
  private apiKey = import.meta.env.VITE_GOOGLE_PLACES_API_KEY || '';

  async fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    if (!this.apiKey) {
      return new MockRestaurantAdapter().fetchRestaurants(params);
    }
    // Example Google Places API TextSearch:
    /*
    const response = await fetch(`/api/places/restaurants?query=${encodeURIComponent('best restaurants in ' + params.destination)}&key=${this.apiKey}`);
    const data = await response.json();
    return transformPlacesResponse(data);
    */
    return new MockRestaurantAdapter().fetchRestaurants(params);
  }
}

export class LiveSkyscannerTransportAdapter implements ITransportAdapter {
  private apiKey = import.meta.env.VITE_SKYSCANNER_API_KEY || '';

  async fetchTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    if (!this.apiKey) {
      return new MockTransportAdapter().fetchTransport(params);
    }
    return new MockTransportAdapter().fetchTransport(params);
  }
}

// -------------------------------------------------------------
// MOCK ADAPTERS (Generates realistic, rich data tailored to input)
// -------------------------------------------------------------
export class MockHotelAdapter implements IHotelAdapter {
  async fetchHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    // Simulate real network trip latency
    await new Promise((resolve) => setTimeout(resolve, 600));

    const dest = params.destination.split(',')[0].trim();
    const city = dest || 'City Center';

    return [
      {
        id: 'hotel-1',
        name: `The Grand Palace Hotel ${city}`,
        tagline: `5-star luxury in the historical center of ${city}`,
        photo: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1582719508461-905c673771fd?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.9,
        reviewsCount: 1420,
        pricePerNight: 285,
        priceRange: '$$$$',
        distanceFromCenterKm: 0.4,
        neighborhood: 'Central Historic District',
        availability: 'Few rooms left',
        amenities: ['Free High-Speed Wi-Fi', 'Rooftop Heated Pool', 'Michelin Restaurant', 'Full Luxury Spa', 'Airport Chauffeur'],
        highlights: ['Spectacular skyline views', 'Complimentary breakfast', '24/7 Butler service'],
        bookingUrl: createHotelBookingDeepLink(`The Grand Palace Hotel`, city, params.startDate, params.durationDays),
        provider: 'Booking.com',
        address: `14 Boulevard Royale, ${city}`,
      },
      {
        id: 'hotel-2',
        name: `${city} Riverside Boutique & Spa`,
        tagline: 'Artful design, tranquil garden terrace, and craft cocktail bar',
        photo: 'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.7,
        reviewsCount: 890,
        pricePerNight: 175,
        priceRange: '$$$',
        distanceFromCenterKm: 1.1,
        neighborhood: 'Arts & Riverfront Quarter',
        availability: 'Available',
        amenities: ['River View Balconies', 'Locally Sourced Organic Breakfast', 'Free Bikes', 'Espresso Lounge', 'Pet Friendly'],
        highlights: ['Walking distance to top galleries', 'Quiet courtyards', 'Designer interior'],
        bookingUrl: createHotelBookingDeepLink(`${city} Riverside Boutique`, city, params.startDate, params.durationDays),
        provider: 'Booking.com',
        address: `45 Riverside Promenade, ${city}`,
      },
      {
        id: 'hotel-3',
        name: `Urban Oasis Loft & Suites`,
        tagline: 'Modern loft living with kitchenettes, co-working hub, and fitness center',
        photo: 'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1618773928121-c32242e63f39?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.5,
        reviewsCount: 654,
        pricePerNight: 115,
        priceRange: '$$',
        distanceFromCenterKm: 1.8,
        neighborhood: 'Midtown Innovation Hub',
        availability: 'High demand',
        amenities: ['Fast Wi-Fi (300 Mbps)', 'Gym & Yoga Studio', 'In-room Espresso', 'Keyless Mobile Entry', 'Laundry'],
        highlights: ['Next to Metro station', 'Spacious work desks', 'Great cafe on ground floor'],
        bookingUrl: createHotelBookingDeepLink(`Urban Oasis Loft`, city, params.startDate, params.durationDays),
        provider: 'Booking.com',
        address: `108 Avenue Central, ${city}`,
      },
      {
        id: 'hotel-4',
        name: `${city} Traveler's Nest & Social Club`,
        tagline: 'Budget-friendly, ultra-clean rooms with vibrant social vibes and rooftop cinema',
        photo: 'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1584132967334-10e028bd69f7?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.3,
        reviewsCount: 1102,
        pricePerNight: 68,
        priceRange: '$',
        distanceFromCenterKm: 2.3,
        neighborhood: 'Bohemian Market District',
        availability: 'Available today',
        amenities: ['Complimentary Coffee & Tea', 'Rooftop Lounge', 'Luggage Storage', 'Weekly Walking Tours', 'Communal Kitchen'],
        highlights: ['Best budget value', 'Friendly international community', 'Near night food market'],
        bookingUrl: createHotelBookingDeepLink(`${city} Travelers Nest`, city, params.startDate, params.durationDays),
        provider: 'Booking.com',
        address: `22 Market Street, ${city}`,
      },
      {
        id: 'hotel-5',
        name: `Villa Belle Époque Retreat`,
        tagline: 'Charming 19th-century villa surrounded by serene botanical courtyards',
        photo: 'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.8,
        reviewsCount: 520,
        pricePerNight: 230,
        priceRange: '$$$',
        distanceFromCenterKm: 1.4,
        neighborhood: 'Old Embassy Quarter',
        availability: 'Few rooms left',
        amenities: ['Private Garden Patios', 'Wine Tastings', 'Concierge Service', 'Heated Marble Baths', 'Room Service'],
        highlights: ['Romantic ambiance', 'Signature wine cellar', 'Quiet residential charm'],
        bookingUrl: createHotelBookingDeepLink(`Villa Belle Epoque Retreat`, city, params.startDate, params.durationDays),
        provider: 'Booking.com',
        address: `7 Garden Way, ${city}`,
      },
    ];
  }
}

export class MockRestaurantAdapter implements IRestaurantAdapter {
  async fetchRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    await new Promise((resolve) => setTimeout(resolve, 650));

    const dest = params.destination.split(',')[0].trim();
    const city = dest || 'Downtown';

    return [
      {
        id: 'rest-1',
        name: `L'Atelier Gastronomique`,
        cuisine: 'Modern Fine Dining & Seasonal Fusion',
        photo: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.9,
        reviewsCount: 840,
        priceRange: '$$$$',
        distanceFromCenterKm: 0.6,
        neighborhood: 'Historic Center',
        availability: 'Reservation required',
        specialties: ['Truffle Degustation', 'Dry Aged Wagyu', 'Artisanal Dessert Trolley'],
        features: ['Michelin Recommended', 'Sommelier Pairing', 'Intimate Lighting', 'Valet Parking'],
        bookingUrl: createRestaurantReservationLink(`L Atelier Gastronomique`, city),
        provider: 'OpenTable',
        address: `8 Place des Beaux Arts, ${city}`,
        openingHours: '18:00 - 23:30 (Tues - Sun)',
      },
      {
        id: 'rest-2',
        name: `Trattoria del Sole`,
        cuisine: 'Authentic Handmade Pasta & Woodfired Specialities',
        photo: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.8,
        reviewsCount: 1250,
        priceRange: '$$',
        distanceFromCenterKm: 0.9,
        neighborhood: 'Piazza Quarter',
        availability: 'Tables available',
        specialties: ['Tagliolini al Tartufo', 'Slow-cooked Ragu', 'Pistachio Tiramisu'],
        features: ['Fresh Pasta Made Daily', 'Outdoor Terrace', 'Vegetarian Friendly', 'Great Wine List'],
        bookingUrl: createRestaurantReservationLink(`Trattoria del Sole`, city),
        provider: 'OpenTable',
        address: `33 Piazza Nova, ${city}`,
        openingHours: '12:00 - 15:00, 18:30 - 23:00',
      },
      {
        id: 'rest-3',
        name: `The Botanist Garden Bistro`,
        cuisine: 'Farm-to-Table, Brunch & Craft Cocktails',
        photo: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.7,
        reviewsCount: 710,
        priceRange: '$$$',
        distanceFromCenterKm: 1.2,
        neighborhood: 'Greenhouse Gardens',
        availability: 'Walk-ins welcome',
        specialties: ['Wild Herb Grilled Salmon', 'Organic Bowls', 'Botanical Gin Infusions'],
        features: ['Glasshouse Ceiling', 'Live Acoustic Music', 'Vegan Options', 'Dog Friendly Terrace'],
        bookingUrl: createRestaurantReservationLink(`The Botanist Garden Bistro`, city),
        provider: 'OpenTable',
        address: `19 Green Avenue, ${city}`,
        openingHours: '10:00 - 22:00 Daily',
      },
      {
        id: 'rest-4',
        name: `Umami Izakaya & Ramen Bar`,
        cuisine: 'Japanese Robata Grill & Craft Ramen',
        photo: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.6,
        reviewsCount: 980,
        priceRange: '$$',
        distanceFromCenterKm: 1.5,
        neighborhood: 'East Quarter',
        availability: 'Limited seating',
        specialties: ['Tonkotsu Black Garlic Ramen', 'Wagyu Yakitori', 'Gyoza Dumplings'],
        features: ['Open Kitchen Counter', 'Rare Japanese Whiskies', 'Late Night Bites'],
        bookingUrl: createRestaurantReservationLink(`Umami Izakaya`, city),
        provider: 'OpenTable',
        address: `54 Neon Lane, ${city}`,
        openingHours: '17:00 - 01:00 Daily',
      },
      {
        id: 'rest-5',
        name: `Street Food Haven & Bazaar`,
        cuisine: 'Local Street Delicacies & World Bites',
        photo: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
        gallery: [
          'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
        ],
        rating: 4.5,
        reviewsCount: 1820,
        priceRange: '$',
        distanceFromCenterKm: 1.9,
        neighborhood: 'Old Market Hall',
        availability: 'Walk-ins welcome',
        specialties: ['Crispy Pastries', 'Spiced Skewers', 'Artisan Gelato'],
        features: ['Quick Counter Service', 'Vibrant Local Vibe', 'Budget Friendly', 'Cashless'],
        bookingUrl: createRestaurantReservationLink(`Street Food Haven`, city),
        provider: 'TripAdvisor',
        address: `Market Square Hall 2, ${city}`,
        openingHours: '09:00 - 20:00 Daily',
      }
    ];
  }
}

export class MockTransportAdapter implements ITransportAdapter {
  async fetchTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    await new Promise((resolve) => setTimeout(resolve, 550));

    const dest = params.destination.split(',')[0].trim();
    const city = dest || 'Destination';
    const mode = params.transportMode;

    if (mode === 'Flight') {
      return [
        {
          id: 'flight-1',
          mode: 'Flight',
          operator: 'AeroSky Direct',
          title: `Direct Express to ${city}`,
          duration: '2h 25m',
          departureTime: '08:30 AM',
          arrivalTime: '10:55 AM',
          departureStation: 'Main International Airport (Terminal 2)',
          arrivalStation: `${city} International (Terminal 1)`,
          price: 189,
          priceRange: '$$',
          rating: 4.8,
          availability: 'Seats available',
          features: ['Carry-on included', 'Free Wi-Fi on board', 'Complimentary snack & drinks', 'Eco-efficient jet'],
          bookingUrl: createTransportDeepLink('Flight', city, params.startDate),
          provider: 'Skyscanner',
        },
        {
          id: 'flight-2',
          mode: 'Flight',
          operator: 'Global Wings Club',
          title: `Prime Morning Flight to ${city}`,
          duration: '2h 15m',
          departureTime: '11:15 AM',
          arrivalTime: '01:30 PM',
          departureStation: 'Main International Airport (Terminal 1)',
          arrivalStation: `${city} International (Terminal 2)`,
          price: 245,
          priceRange: '$$$',
          rating: 4.9,
          availability: 'Few seats remaining',
          features: ['Extra legroom', 'Checked bag included', 'Priority boarding', 'In-seat entertainment'],
          bookingUrl: createTransportDeepLink('Flight', city, params.startDate),
          provider: 'Google Flights',
        },
        {
          id: 'flight-3',
          mode: 'Flight',
          operator: 'SunAir Budget Lines',
          title: `Evening Saver Flight to ${city}`,
          duration: '2h 40m',
          departureTime: '07:45 PM',
          arrivalTime: '10:25 PM',
          departureStation: 'City Regional Airport',
          arrivalStation: `${city} West Airport`,
          price: 89,
          priceRange: '$',
          rating: 4.2,
          availability: 'Seats available',
          features: ['Best budget deal', 'Instant mobile check-in', 'USB charging at seat'],
          bookingUrl: createTransportDeepLink('Flight', city, params.startDate),
          provider: 'Skyscanner',
        }
      ];
    }

    if (mode === 'Train') {
      return [
        {
          id: 'train-1',
          mode: 'Train',
          operator: 'EuroRail High-Speed Bullet',
          title: `Panoramic Express to ${city} Central`,
          duration: '3h 10m',
          departureTime: '09:00 AM',
          arrivalTime: '12:10 PM',
          departureStation: 'Central Station Track 4',
          arrivalStation: `${city} Main Terminal`,
          price: 78,
          priceRange: '$$',
          rating: 4.9,
          availability: 'Seats available',
          features: ['Scenic countryside views', 'Dining car bistro', 'Quiet carriage available', 'Power outlets'],
          bookingUrl: createTransportDeepLink('Train', city, params.startDate),
          provider: 'Trainline',
        },
        {
          id: 'train-2',
          mode: 'Train',
          operator: 'NightSleeper Express',
          title: `Overnight Sleeper to ${city}`,
          duration: '7h 30m',
          departureTime: '11:20 PM',
          arrivalTime: '06:50 AM',
          departureStation: 'Grand Central Station',
          arrivalStation: `${city} Central`,
          price: 110,
          priceRange: '$$$',
          rating: 4.7,
          availability: 'Few seats remaining',
          features: ['Private bed compartment', 'Save on 1 night hotel', 'Fresh morning coffee delivered'],
          bookingUrl: createTransportDeepLink('Train', city, params.startDate),
          provider: 'Trainline',
        }
      ];
    }

    if (mode === 'Bus') {
      return [
        {
          id: 'bus-1',
          mode: 'Bus',
          operator: 'FlixConnect Comfort',
          title: `Express Coach to ${city}`,
          duration: '4h 45m',
          departureTime: '08:00 AM',
          arrivalTime: '12:45 PM',
          departureStation: 'Central Bus Terminal Bay 12',
          arrivalStation: `${city} City Center Bus Station`,
          price: 29,
          priceRange: '$',
          rating: 4.4,
          availability: 'Scheduled daily',
          features: ['Free onboard Wi-Fi', 'Reclining seats with USB', 'Restroom onboard', 'Luggage in hold included'],
          bookingUrl: createTransportDeepLink('Bus', city, params.startDate),
          provider: 'Omio',
        },
        {
          id: 'bus-2',
          mode: 'Bus',
          operator: 'StarLine Premium Coach',
          title: `VIP Luxury Coach to ${city}`,
          duration: '4h 15m',
          departureTime: '02:30 PM',
          arrivalTime: '06:45 PM',
          departureStation: 'Westside Transit Hub',
          arrivalStation: `${city} Central Plaza`,
          price: 45,
          priceRange: '$$',
          rating: 4.6,
          availability: 'Seats available',
          features: ['Extra wide leather seats', 'Complimentary cold water', 'Smooth ride'],
          bookingUrl: createTransportDeepLink('Bus', city, params.startDate),
          provider: 'Omio',
        }
      ];
    }

    if (mode === 'Car') {
      return [
        {
          id: 'car-1',
          mode: 'Car',
          operator: 'Enterprise & Hertz Fleet',
          title: `Compact SUV or Hybrid Sedan for ${city} Trip`,
          duration: 'Flexible / On your terms',
          departureTime: 'Pickup whenever ready',
          arrivalTime: 'Unlimited mileage',
          departureStation: 'City Center Pickup Hub',
          arrivalStation: `${city} Drop-off Center`,
          price: 55,
          priceRange: '$$',
          rating: 4.8,
          availability: 'Available today',
          features: ['GPS Navigation included', 'Free cancellation up to 48h', 'Zero deductible option', 'Apple CarPlay & Android Auto'],
          bookingUrl: createTransportDeepLink('Car', city, params.startDate),
          provider: 'Rentalcars',
        },
        {
          id: 'car-2',
          mode: 'Car',
          operator: 'Premium Drive Collections',
          title: `Tesla Model Y / BMW 3 Series`,
          duration: 'Scenic road trip freedom',
          departureTime: 'Anytime',
          arrivalTime: 'Instant keyless unlock',
          departureStation: 'Airport Concierge Desk',
          arrivalStation: `${city} Downtown Hub`,
          price: 95,
          priceRange: '$$$',
          rating: 4.9,
          availability: 'Few seats remaining',
          features: ['Autopilot capability', 'Supercharging included', 'Premium audio system', 'Heated seats'],
          bookingUrl: createTransportDeepLink('Car', city, params.startDate),
          provider: 'Rentalcars',
        }
      ];
    }

    // Cruise
    return [
      {
        id: 'cruise-1',
        mode: 'Cruise',
        operator: 'Royal Seafarer Voyages',
        title: `Coastal Explorer Voyage to ${city}`,
        duration: '1-2 Days scenic sailing',
        departureTime: '04:00 PM Departure',
        arrivalTime: 'Next Day 09:00 AM Docking',
        departureStation: 'International Cruise Port Dock 3',
        arrivalStation: `${city} Harbour Pier`,
        price: 260,
        priceRange: '$$$$',
        rating: 4.8,
        availability: 'Filling fast',
        features: ['Oceanview Stateroom', 'All Meals & Buffets included', 'Live Evening Shows', 'Sunset Sundeck'],
        bookingUrl: createTransportDeepLink('Cruise', city, params.startDate),
        provider: 'Google Flights',
      }
    ];
  }
}

// -------------------------------------------------------------
// CENTRAL REPOSITORY / SERVICE COORDINATOR
// -------------------------------------------------------------
class TravelService {
  private hotelAdapter: IHotelAdapter = new MockHotelAdapter();
  private restaurantAdapter: IRestaurantAdapter = new MockRestaurantAdapter();
  private transportAdapter: ITransportAdapter = new MockTransportAdapter();

  // Allow dynamic plugging of custom live adapters
  public setHotelAdapter(adapter: IHotelAdapter) {
    this.hotelAdapter = adapter;
  }

  public setRestaurantAdapter(adapter: IRestaurantAdapter) {
    this.restaurantAdapter = adapter;
  }

  public setTransportAdapter(adapter: ITransportAdapter) {
    this.transportAdapter = adapter;
  }

  public async getHotels(params: TravelServiceParams): Promise<HotelRecommendation[]> {
    return this.hotelAdapter.fetchHotels(params);
  }

  public async getRestaurants(params: TravelServiceParams): Promise<RestaurantRecommendation[]> {
    return this.restaurantAdapter.fetchRestaurants(params);
  }

  public async getTransport(params: TravelServiceParams): Promise<TransportOption[]> {
    return this.transportAdapter.fetchTransport(params);
  }
}

export const travelService = new TravelService();

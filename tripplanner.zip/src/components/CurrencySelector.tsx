import React, { useState, useRef, useEffect } from 'react';
import { useCurrency, CurrencyCode } from '../context/CurrencyContext';
import { ChevronDown, Check, Coins } from 'lucide-react';

export const CurrencySelector: React.FC = () => {
  const { currency, setCurrency, currencyInfo, availableCurrencies } = useCurrency();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Select currency"
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-white/10 hover:border-teal-500/40 text-xs font-semibold text-slate-200 transition shadow-sm cursor-pointer group"
      >
        <span className="text-sm">{currencyInfo.flag}</span>
        <span className="font-mono text-teal-300 font-bold">{currencyInfo.symbol}</span>
        <span className="font-semibold text-white tracking-wide">{currencyInfo.code}</span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 group-hover:text-teal-400 transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-teal-400' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-slate-900/95 backdrop-blur-2xl border border-white/15 shadow-2xl z-50 p-1.5 animate-in fade-in slide-in-from-top-2">
          <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 border-b border-white/10 mb-1">
            <Coins className="w-3.5 h-3.5 text-teal-400" />
            <span>Select Currency</span>
          </div>

          <div className="max-h-64 overflow-y-auto space-y-0.5 pr-0.5">
            {availableCurrencies.map((c) => {
              const isSelected = c.code === currency;
              return (
                <button
                  key={c.code}
                  onClick={() => {
                    setCurrency(c.code as CurrencyCode);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs transition cursor-pointer text-left ${
                    isSelected
                      ? 'bg-teal-500/20 text-teal-300 font-bold border border-teal-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <span className="text-base">{c.flag}</span>
                    <div>
                      <div className="font-semibold text-white flex items-center gap-1.5">
                        <span>{c.code}</span>
                        <span className="font-mono text-teal-400 text-xs">({c.symbol})</span>
                      </div>
                      <div className="text-[10px] text-slate-400 leading-none mt-0.5">
                        {c.name}
                      </div>
                    </div>
                  </div>

                  {isSelected && (
                    <Check className="w-4 h-4 text-teal-400 stroke-[3] shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          <div className="px-3 py-1.5 mt-1 border-t border-white/10 text-[10px] text-slate-400 text-center">
            Rates auto-converted across all tabs
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  X,
  MapPin,
  Calendar,
  Clock,
  Plane,
  Trash2,
  Plus,
  ArrowRight,
  FolderHeart,
} from 'lucide-react';
import { Trip } from '../types';
import { getUserTrips, deleteExpense } from '../services/firestoreService';
import { db, doc, deleteDoc, User } from '../firebase';

interface SavedTripsModalProps {
  user: User;
  activeTripId?: string;
  onSelectTrip: (trip: Trip) => void;
  onPlanNewTrip: () => void;
  onClose: () => void;
}

export const SavedTripsModal: React.FC<SavedTripsModalProps> = ({
  user,
  activeTripId,
  onSelectTrip,
  onPlanNewTrip,
  onClose,
}) => {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [loading, setLoading] = useState(true);
  const [deletingTripId, setDeletingTripId] = useState<string | null>(null);

  const fetchTrips = async () => {
    setLoading(true);
    try {
      const list = await getUserTrips(user.uid);
      setTrips(list);
    } catch (err) {
      console.error('Failed to load trips:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrips();
  }, [user.uid]);

  const handleDelete = async (tripId: string) => {
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'trips', tripId));
      setTrips((prev) => prev.filter((t) => t.id !== tripId));
      setDeletingTripId(null);
    } catch (err) {
      console.error('Failed to delete trip:', err);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl max-h-[85vh] overflow-y-auto rounded-3xl bg-slate-900 border border-white/15 p-6 sm:p-8 shadow-2xl text-white relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close saved trips"
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
            <FolderHeart className="w-5 h-5 text-rose-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">My Saved Trips</h2>
            <p className="text-xs text-slate-400">
              Select any trip to view recommendations or manage expenses
            </p>
          </div>
        </div>

        {/* Action: Plan New Trip */}
        <button
          onClick={() => {
            onPlanNewTrip();
            onClose();
          }}
          className="w-full mb-5 py-3 px-4 rounded-2xl bg-teal-500/15 hover:bg-teal-500/25 border border-teal-500/30 text-teal-300 font-semibold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Plan a Fresh Trip</span>
        </button>

        {loading ? (
          <div className="space-y-3 py-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-20 rounded-2xl bg-slate-800/60 animate-pulse border border-white/5"
              />
            ))}
          </div>
        ) : trips.length === 0 ? (
          <div className="py-12 text-center text-slate-400 text-xs">
            No saved trips yet. Use the trip form to design your first itinerary!
          </div>
        ) : (
          <div className="space-y-3">
            {trips.map((t) => {
              const isActive = t.id === activeTripId;
              return (
                <div
                  key={t.id}
                  className={`p-4 rounded-2xl border transition-all flex items-center justify-between gap-4 cursor-pointer ${
                    isActive
                      ? 'bg-teal-500/15 border-teal-400/50 shadow-md'
                      : 'bg-slate-950/60 hover:bg-slate-800/80 border-white/5'
                  }`}
                  onClick={() => {
                    onSelectTrip(t);
                    onClose();
                  }}
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-teal-400 shrink-0">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white flex items-center gap-2">
                        <span>{t.destination}</span>
                        <span className="text-xs font-normal text-slate-400">
                          , {t.destinationCountry}
                        </span>
                        {isActive && (
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-400 text-slate-950 font-bold">
                            Active
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-teal-400" />
                          <span>{t.startDate}</span>
                        </span>
                        <span>•</span>
                        <span>{t.durationDays} Days</span>
                        <span>•</span>
                        <span>{t.transportMode}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                    {deletingTripId === t.id ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => t.id && handleDelete(t.id)}
                          className="px-2 py-1 rounded bg-rose-500 text-white text-[10px] font-bold"
                        >
                          Confirm
                        </button>
                        <button
                          onClick={() => setDeletingTripId(null)}
                          className="px-2 py-1 rounded bg-slate-800 text-slate-300 text-[10px]"
                        >
                          Cancel
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => t.id && setDeletingTripId(t.id)}
                        className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                        title="Delete Trip"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}

                    <div className="text-slate-400 hover:text-white p-1">
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

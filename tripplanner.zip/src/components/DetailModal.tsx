import React, { useState } from 'react';
import {
  X,
  Star,
  MapPin,
  ExternalLink,
  CheckCircle2,
  Calendar,
  Clock,
  ShieldCheck,
  ChevronLeft,
  ChevronRight,
  Info,
} from 'lucide-react';
import { HotelRecommendation, RestaurantRecommendation, TransportOption } from '../types';
import { useCurrency } from '../context/CurrencyContext';

interface DetailModalProps {
  item: HotelRecommendation | RestaurantRecommendation | TransportOption | null;
  type: 'hotel' | 'restaurant' | 'transport';
  onClose: () => void;
  tripDestination: string;
  tripDates: string;
}

export const DetailModal: React.FC<DetailModalProps> = ({
  item,
  type,
  onClose,
  tripDestination,
  tripDates,
}) => {
  const { formatPriceFromUSD } = useCurrency();
  const [photoIndex, setPhotoIndex] = useState(0);

  if (!item) return null;

  const isHotel = type === 'hotel';
  const isRestaurant = type === 'restaurant';
  const isTransport = type === 'transport';

  const hotel = isHotel ? (item as HotelRecommendation) : null;
  const restaurant = isRestaurant ? (item as RestaurantRecommendation) : null;
  const transport = isTransport ? (item as TransportOption) : null;

  const gallery = isHotel ? hotel?.gallery || [hotel!.photo] : isRestaurant ? restaurant?.gallery || [restaurant!.photo] : [];

  const handlePrevPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPhotoIndex((prev) => (prev - 1 + gallery.length) % gallery.length);
  };

  const handleNextPhoto = (e: React.MouseEvent) => {
    e.stopPropagation();
    setPhotoIndex((prev) => (prev + 1) % gallery.length);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-white/15 text-white shadow-2xl p-6 sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close details"
          className="absolute top-5 right-5 z-10 p-2 rounded-full bg-slate-950/70 hover:bg-slate-800 text-slate-300 hover:text-white transition border border-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Photo Gallery Carousel */}
        {gallery.length > 0 && (
          <div className="relative w-full h-64 sm:h-72 rounded-2xl overflow-hidden mb-6 group border border-white/10">
            <img
              src={gallery[photoIndex] || (isHotel ? hotel?.photo : restaurant?.photo)}
              alt={isHotel ? hotel?.name : restaurant?.name}
              className="w-full h-full object-cover transition-all duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

            {gallery.length > 1 && (
              <>
                <button
                  onClick={handlePrevPhoto}
                  aria-label="Previous photo"
                  className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/60 hover:bg-slate-900 text-white transition border border-white/10"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextPhoto}
                  aria-label="Next photo"
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-slate-950/60 hover:bg-slate-900 text-white transition border border-white/10"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <div className="absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-slate-950/70 text-[11px] font-mono border border-white/10">
                  {photoIndex + 1} / {gallery.length}
                </div>
              </>
            )}

            <div className="absolute bottom-3 left-3 flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-teal-500 text-slate-950">
                {isHotel ? hotel?.provider : restaurant ? restaurant.provider : transport?.provider}
              </span>
              <span className="px-2.5 py-1 rounded-full text-xs font-medium bg-slate-900/80 text-teal-300 border border-teal-500/30">
                {isHotel ? hotel?.availability : restaurant ? restaurant.availability : transport?.availability}
              </span>
            </div>
          </div>
        )}

        {/* Content Details */}
        <div className="space-y-5">
          <div>
            <div className="flex items-center gap-2 text-xs text-teal-400 font-semibold uppercase tracking-wider mb-1">
              <span>{isHotel ? 'Luxury Stay' : isRestaurant ? restaurant?.cuisine : `${transport?.mode} Route`}</span>
              <span>•</span>
              <span>{tripDestination}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
              {isHotel ? hotel?.name : isRestaurant ? restaurant?.name : transport?.title}
            </h2>
            <p className="text-sm text-slate-300 mt-1">
              {isHotel ? hotel?.tagline : isRestaurant ? `Specialty: ${restaurant?.specialties.join(', ')}` : transport?.operator}
            </p>
          </div>

          {/* Key Metrics Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 border-y border-white/10">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <div>
                <div className="text-xs text-slate-400">Rating</div>
                <div className="text-sm font-bold text-white">
                  {isHotel ? hotel?.rating : isRestaurant ? restaurant?.rating : transport?.rating} / 5.0
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-teal-400" />
              <div>
                <div className="text-xs text-slate-400">Distance</div>
                <div className="text-sm font-bold text-white">
                  {isHotel
                    ? `${hotel?.distanceFromCenterKm} km to center`
                    : isRestaurant
                    ? `${restaurant?.distanceFromCenterKm} km to center`
                    : 'Direct arrival'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <div>
                <div className="text-xs text-slate-400">Price Tier</div>
                <div className="text-sm font-bold text-teal-300">
                  {isHotel
                    ? `${hotel?.priceRange} • ${formatPriceFromUSD(hotel!.pricePerNight)}/night`
                    : isRestaurant
                    ? restaurant?.priceRange
                    : `${transport?.priceRange} • ${formatPriceFromUSD(transport!.price)}`}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <div>
                <div className="text-xs text-slate-400">Status</div>
                <div className="text-xs font-semibold text-emerald-300 truncate">
                  {isHotel ? hotel?.availability : isRestaurant ? restaurant?.availability : transport?.availability}
                </div>
              </div>
            </div>
          </div>

          {/* Location & Opening info */}
          {(isHotel || isRestaurant) && (
            <div className="p-3.5 rounded-xl bg-slate-950/60 border border-white/5 space-y-1.5 text-xs text-slate-300">
              <div className="flex items-center gap-2 text-slate-200">
                <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                <span className="font-semibold">Address:</span>
                <span>{isHotel ? hotel?.address : restaurant?.address}</span>
              </div>
              {isRestaurant && restaurant?.openingHours && (
                <div className="flex items-center gap-2 text-slate-300">
                  <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="font-semibold">Hours:</span>
                  <span>{restaurant.openingHours}</span>
                </div>
              )}
            </div>
          )}

          {/* Transport stations if transport option */}
          {isTransport && transport && (
            <div className="p-4 rounded-xl bg-slate-950/60 border border-white/5 space-y-2 text-xs">
              <div className="flex items-center justify-between font-semibold text-slate-200">
                <span>Departure: {transport.departureTime}</span>
                <span>Arrival: {transport.arrivalTime}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400 text-[11px]">
                <span>{transport.departureStation}</span>
                <span>➔</span>
                <span>{transport.arrivalStation}</span>
              </div>
              <div className="text-teal-300 font-semibold pt-1">
                Duration: {transport.duration}
              </div>
            </div>
          )}

          {/* Highlights & Amenities */}
          <div>
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Highlights & Included Features
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {(isHotel
                ? [...hotel!.amenities, ...hotel!.highlights]
                : isRestaurant
                ? [...restaurant!.features, ...restaurant!.specialties]
                : transport!.features
              ).map((feature, i) => (
                <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Bottom Action / Direct Link */}
          <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="text-xs text-slate-400 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-teal-400" />
              <span>Redirects with dates & destination prefilled</span>
            </div>

            <a
              href={item.bookingUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 transition cursor-pointer"
            >
              <span>
                {isHotel ? 'Book on Booking.com' : isRestaurant ? 'Reserve on OpenTable' : 'View on Skyscanner'}
              </span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

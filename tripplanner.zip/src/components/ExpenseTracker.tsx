import React, { useState, useEffect, useMemo } from 'react';
import {
  Receipt,
  Plus,
  Trash2,
  Edit2,
  DollarSign,
  PieChart,
  Calendar,
  AlertTriangle,
  CheckCircle,
  X,
  Search,
  Filter,
  Save,
  Wallet,
  TrendingDown,
  Building,
  Utensils,
  Plane,
  Ticket,
  ShoppingBag,
  HelpCircle,
} from 'lucide-react';
import { Trip, Expense, ExpenseCategory } from '../types';
import {
  addExpense,
  updateExpense,
  deleteExpense,
  subscribeToTripExpenses,
  updateTrip,
} from '../services/firestoreService';
import { User } from '../firebase';
import { useCurrency, CurrencyCode, CURRENCY_MAP } from '../context/CurrencyContext';

interface ExpenseTrackerProps {
  user: User;
  trip: Trip;
  onUpdateTripBudget: (budget: number) => void;
}

const CATEGORIES: { label: ExpenseCategory; icon: any; color: string; bg: string }[] = [
  { label: 'Stay', icon: Building, color: '#38bdf8', bg: 'rgba(56, 189, 248, 0.15)' },
  { label: 'Food', icon: Utensils, color: '#f59e0b', bg: 'rgba(245, 158, 11, 0.15)' },
  { label: 'Transport', icon: Plane, color: '#14b8a6', bg: 'rgba(20, 184, 166, 0.15)' },
  { label: 'Activities', icon: Ticket, color: '#a855f7', bg: 'rgba(168, 85, 247, 0.15)' },
  { label: 'Shopping', icon: ShoppingBag, color: '#ec4899', bg: 'rgba(236, 72, 153, 0.15)' },
  { label: 'Other', icon: HelpCircle, color: '#94a3b8', bg: 'rgba(148, 163, 184, 0.15)' },
];

const CURRENCIES: CurrencyCode[] = ['USD', 'INR', 'JPY', 'EUR', 'GBP', 'AUD', 'CAD', 'AED', 'SGD'];

export const ExpenseTracker: React.FC<ExpenseTrackerProps> = ({
  user,
  trip,
  onUpdateTripBudget,
}) => {
  const { currency: activeCurrency, currencyInfo, convertBetween, formatAmount } = useCurrency();
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  // Budget management
  const [budgetInput, setBudgetInput] = useState<string>(trip.budget ? String(trip.budget) : '1500');
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [budgetSaving, setBudgetSaving] = useState(false);

  // Form modal state (Add / Edit)
  const [modalOpen, setModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [amount, setAmount] = useState<string>('');
  const [category, setCategory] = useState<ExpenseCategory>('Food');
  const [date, setDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [note, setNote] = useState<string>('');
  const [currency, setCurrency] = useState<string>(activeCurrency);
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Delete confirmation
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Subscribe to real-time expenses in Firestore
  useEffect(() => {
    if (!trip.id) return;
    setLoading(true);

    const unsubscribe = subscribeToTripExpenses(user.uid, trip.id, (loadedExpenses) => {
      setExpenses(loadedExpenses);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user.uid, trip.id]);

  // Open modal for new expense
  const handleOpenAdd = () => {
    setEditingExpense(null);
    setAmount('');
    setCategory('Food');
    setDate(new Date().toISOString().split('T')[0]);
    setNote('');
    setCurrency(activeCurrency);
    setFormError(null);
    setModalOpen(true);
  };

  // Open modal for editing existing expense
  const handleOpenEdit = (exp: Expense) => {
    setEditingExpense(exp);
    setAmount(String(exp.amount));
    setCategory(exp.category);
    setDate(exp.date);
    setNote(exp.note);
    setCurrency(exp.currency || trip.currency || 'USD');
    setFormError(null);
    setModalOpen(true);
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      setFormError('Please enter a valid expense amount greater than 0.');
      return;
    }

    if (!date) {
      setFormError('Please select a valid date.');
      return;
    }

    if (!trip.id) {
      setFormError('Trip ID is not available.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (editingExpense) {
        await updateExpense(user.uid, trip.id, editingExpense.id, {
          amount: numAmount,
          category,
          date,
          note: note.trim() || category,
          currency,
        });
      } else {
        await addExpense(user.uid, trip.id, {
          userId: user.uid,
          tripId: trip.id,
          amount: numAmount,
          category,
          date,
          note: note.trim() || category,
          currency,
        });
      }
      setModalOpen(false);
    } catch (err) {
      console.error('Error saving expense:', err);
      setFormError('Failed to save expense. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteExpense = async (expenseId: string) => {
    if (!trip.id) return;
    try {
      await deleteExpense(user.uid, trip.id, expenseId);
      setDeletingId(null);
    } catch (err) {
      console.error('Error deleting expense:', err);
    }
  };

  const handleSaveBudget = async () => {
    if (!trip.id) return;
    const num = parseFloat(budgetInput);
    if (isNaN(num) || num < 0) return;

    setBudgetSaving(true);
    try {
      await updateTrip(user.uid, trip.id, { budget: num });
      onUpdateTripBudget(num);
      setIsEditingBudget(false);
    } catch (err) {
      console.error('Error updating budget:', err);
    } finally {
      setBudgetSaving(false);
    }
  };

  // Helper to convert expense into active currency
  const getExpenseInActiveCurrency = (exp: Expense) => {
    const fromCur = (exp.currency || 'USD') as CurrencyCode;
    return convertBetween(exp.amount, fromCur, activeCurrency);
  };

  // Calculations in active currency
  const totalSpent = useMemo(() => {
    return expenses.reduce((acc, curr) => {
      const fromCur = (curr.currency || 'USD') as CurrencyCode;
      return acc + convertBetween(curr.amount, fromCur, activeCurrency);
    }, 0);
  }, [expenses, activeCurrency, convertBetween]);

  const tripBudget = useMemo(() => {
    const baseBudget = trip.budget !== undefined ? trip.budget : parseFloat(budgetInput) || 1500;
    const tripCur = (trip.currency || 'USD') as CurrencyCode;
    return convertBetween(baseBudget, tripCur, activeCurrency);
  }, [trip.budget, trip.currency, budgetInput, activeCurrency, convertBetween]);

  const remainingBudget = tripBudget - totalSpent;
  const budgetPercentage = tripBudget > 0 ? Math.min(100, Math.round((totalSpent / tripBudget) * 100)) : 0;
  const isOverBudget = remainingBudget < 0;

  // Breakdown by Category in active currency
  const categoryBreakdown = useMemo(() => {
    const map: Record<ExpenseCategory, number> = {
      Stay: 0,
      Food: 0,
      Transport: 0,
      Activities: 0,
      Shopping: 0,
      Other: 0,
    };

    expenses.forEach((e) => {
      const fromCur = (e.currency || 'USD') as CurrencyCode;
      const inActive = convertBetween(e.amount, fromCur, activeCurrency);
      if (map[e.category] !== undefined) {
        map[e.category] += inActive;
      } else {
        map.Other += inActive;
      }
    });

    return CATEGORIES.map((cat) => ({
      ...cat,
      total: map[cat.label],
      percent: totalSpent > 0 ? Math.round((map[cat.label] / totalSpent) * 100) : 0,
    }));
  }, [expenses, totalSpent, activeCurrency, convertBetween]);

  // Filtered expenses list
  const filteredExpenses = useMemo(() => {
    return expenses.filter((e) => {
      if (selectedCategoryFilter !== 'all' && e.category !== selectedCategoryFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          e.note.toLowerCase().includes(q) ||
          e.category.toLowerCase().includes(q) ||
          String(e.amount).includes(q)
        );
      }
      return true;
    });
  }, [expenses, selectedCategoryFilter, searchQuery]);

  // SVG Donut Chart calculations
  const donutSlices = useMemo(() => {
    if (totalSpent === 0) return [];
    let cumulativeAngle = 0;
    const radius = 64;
    const circumference = 2 * Math.PI * radius;

    return categoryBreakdown
      .filter((c) => c.total > 0)
      .map((c) => {
        const slicePercent = c.total / totalSpent;
        const strokeDash = slicePercent * circumference;
        const strokeOffset = -cumulativeAngle * circumference;
        cumulativeAngle += slicePercent;
        return {
          ...c,
          strokeDash: `${strokeDash} ${circumference - strokeDash}`,
          strokeOffset,
        };
      });
  }, [categoryBreakdown, totalSpent]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
      {/* Top Banner / Heading */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 mb-8 border border-white/15 shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-400 uppercase tracking-wider mb-1">
            <Receipt className="w-4 h-4" />
            <span>Trip Finance & Ledger</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Expense Tracker
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Tracking manual spending for <strong className="text-teal-300 font-semibold">{trip.destination}</strong> ({trip.durationDays} days)
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-xl shadow-teal-500/25 transition cursor-pointer"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>Add New Expense</span>
        </button>
      </div>

      {/* Stats Cards & Budget Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Card 1: Total Spent */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Total Spent
            </span>
            <div className="text-3xl font-extrabold text-white mt-1">
              {formatAmount(totalSpent, activeCurrency)}
            </div>
            <span className="text-[11px] text-teal-300 mt-1 block font-medium">
              {expenses.length} recorded items
            </span>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-300 font-bold font-mono text-xl">
            {currencyInfo.symbol}
          </div>
        </div>

        {/* Card 2: Trip Budget */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Trip Budget
            </span>
            <button
              onClick={() => setIsEditingBudget(!isEditingBudget)}
              className="text-xs text-teal-400 hover:text-teal-300 underline font-medium"
            >
              {isEditingBudget ? 'Cancel' : 'Edit'}
            </button>
          </div>

          {isEditingBudget ? (
            <div className="flex items-center gap-2 mt-1">
              <input
                type="number"
                value={budgetInput}
                onChange={(e) => setBudgetInput(e.target.value)}
                className="w-full px-3 py-1.5 rounded-xl glass-input text-lg font-bold text-white"
                placeholder={`Budget (${currencyInfo.symbol})`}
              />
              <button
                onClick={handleSaveBudget}
                disabled={budgetSaving}
                className="p-2 rounded-xl bg-teal-500 text-slate-950 font-bold"
              >
                <Save className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="text-3xl font-extrabold text-white mt-1">
              {formatAmount(tripBudget, activeCurrency)}
            </div>
          )}

          <div className="text-[11px] text-slate-400 mt-1">
            Target travel budget in Firestore ({activeCurrency})
          </div>
        </div>

        {/* Card 3: Remaining Balance */}
        <div className="glass-card rounded-3xl p-6 border border-white/10 flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Remaining Balance
            </span>
            <div
              className={`text-3xl font-extrabold mt-1 ${
                isOverBudget ? 'text-rose-400' : 'text-emerald-400'
              }`}
            >
              {isOverBudget ? '-' : ''}{formatAmount(Math.abs(remainingBudget), activeCurrency)}
            </div>
            <span
              className={`text-[11px] mt-1 block font-medium ${
                isOverBudget ? 'text-rose-300' : 'text-emerald-300'
              }`}
            >
              {isOverBudget
                ? `Over budget by ${formatAmount(Math.abs(remainingBudget), activeCurrency)}`
                : 'Within planned limits'}
            </span>
          </div>
          <div
            className={`w-12 h-12 rounded-2xl border flex items-center justify-center ${
              isOverBudget
                ? 'bg-rose-500/20 border-rose-500/30 text-rose-300'
                : 'bg-emerald-500/20 border-emerald-500/30 text-emerald-300'
            }`}
          >
            <Wallet className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Budget Progress Bar */}
      <div className="glass-card rounded-2xl p-4 sm:p-5 mb-8 border border-white/10">
        <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
          <span className="font-semibold flex items-center gap-1.5">
            {isOverBudget ? (
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            ) : (
              <CheckCircle className="w-4 h-4 text-emerald-400" />
            )}
            <span>Budget Utilization: {budgetPercentage}%</span>
          </span>
          <span className="text-slate-400">
            {formatAmount(totalSpent, activeCurrency)} of {formatAmount(tripBudget, activeCurrency)}
          </span>
        </div>

        <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden p-0.5 border border-white/5">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              isOverBudget
                ? 'bg-gradient-to-r from-rose-500 to-red-600'
                : budgetPercentage > 80
                ? 'bg-gradient-to-r from-amber-400 to-amber-500'
                : 'bg-gradient-to-r from-teal-400 to-emerald-400'
            }`}
            style={{ width: `${Math.min(100, (totalSpent / (tripBudget || 1)) * 100)}%` }}
          />
        </div>
      </div>

      {/* Main Content Layout: Donut Chart & Expenses Table */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* LEFT COLUMN: Donut Chart & Category Breakdown */}
        <div className="glass-card rounded-3xl p-6 sm:p-7 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <PieChart className="w-4 h-4 text-teal-400" />
                <span>Category Breakdown</span>
              </h2>
              <span className="text-xs text-slate-400">Donut Distribution</span>
            </div>

            {/* SVG Donut Chart */}
            {totalSpent > 0 ? (
              <div className="flex flex-col items-center my-4">
                <div className="relative w-44 h-44">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 160 160">
                    <circle
                      cx="80"
                      cy="80"
                      r="64"
                      className="text-slate-800"
                      strokeWidth="20"
                      stroke="currentColor"
                      fill="transparent"
                    />
                    {donutSlices.map((slice, i) => (
                      <circle
                        key={i}
                        cx="80"
                        cy="80"
                        r="64"
                        stroke={slice.color}
                        strokeWidth="20"
                        strokeDasharray={slice.strokeDash}
                        strokeDashoffset={slice.strokeOffset}
                        strokeLinecap="round"
                        fill="transparent"
                        className="transition-all duration-500 hover:opacity-80"
                      />
                    ))}
                  </svg>
                  {/* Center Text */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-[10px] uppercase font-semibold text-slate-400">
                      Total ({activeCurrency})
                    </span>
                    <span className="text-base font-extrabold text-white">
                      {formatAmount(totalSpent, activeCurrency)}
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-slate-500 text-xs">
                No expenses logged yet. Add one to see the visual breakdown!
              </div>
            )}

            {/* Category breakdown rows */}
            <div className="space-y-2.5 mt-4">
              {categoryBreakdown.map((cat) => {
                const Icon = cat.icon;
                return (
                  <div
                    key={cat.label}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-900/40 border border-white/5 text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                        style={{ backgroundColor: cat.bg, color: cat.color }}
                      >
                        <Icon className="w-3.5 h-3.5" />
                      </div>
                      <span className="font-semibold text-slate-200">{cat.label}</span>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-white">
                        {formatAmount(cat.total, activeCurrency)}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {cat.percent}%
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Expenses List Table & Actions */}
        <div className="lg:col-span-2 glass-card rounded-3xl p-6 sm:p-7 border border-white/10 flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 mb-6">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Receipt className="w-4 h-4 text-teal-400" />
                <span>Recorded Expenses ({filteredExpenses.length})</span>
              </h2>

              {/* Category Filter & Search Box */}
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-44">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search notes..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-xl glass-input text-xs text-white placeholder-slate-400"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5 pointer-events-none" />
                </div>

                <select
                  value={selectedCategoryFilter}
                  onChange={(e) => setSelectedCategoryFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-slate-200 bg-slate-900 focus:outline-none cursor-pointer"
                >
                  <option value="all">All Categories</option>
                  {CATEGORIES.map((c) => (
                    <option key={c.label} value={c.label}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Expenses List */}
            {loading ? (
              <div className="space-y-3 py-4">
                {[1, 2, 3, 4].map((i) => (
                  <div
                    key={i}
                    className="h-16 rounded-2xl bg-slate-800/60 animate-pulse border border-white/5"
                  />
                ))}
              </div>
            ) : filteredExpenses.length === 0 ? (
              <div className="py-14 text-center">
                <div className="w-12 h-12 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 mx-auto mb-3">
                  <Receipt className="w-6 h-6" />
                </div>
                <h3 className="text-sm font-semibold text-white">No expenses found</h3>
                <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
                  {searchQuery || selectedCategoryFilter !== 'all'
                    ? 'No matching records for your current filters.'
                    : 'Start tracking meals, hotels, transit, and activities by clicking below.'}
                </p>
                <button
                  onClick={handleOpenAdd}
                  className="mt-4 px-4 py-2 rounded-xl bg-teal-500 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Log Expense</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
                {filteredExpenses.map((exp) => {
                  const catConfig = CATEGORIES.find((c) => c.label === exp.category) || CATEGORIES[5];
                  const Icon = catConfig.icon;

                  return (
                    <div
                      key={exp.id}
                      className="p-3.5 rounded-2xl bg-slate-900/60 hover:bg-slate-900 border border-white/5 flex items-center justify-between gap-4 transition group"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                          style={{ backgroundColor: catConfig.bg, color: catConfig.color }}
                        >
                          <Icon className="w-5 h-5" />
                        </div>
                        <div>
                          <div className="text-sm font-semibold text-white flex items-center gap-2">
                            <span>{exp.note}</span>
                            <span className="text-[10px] px-2 py-0.2 rounded-md bg-slate-800 text-slate-300 border border-white/5">
                              {exp.category}
                            </span>
                          </div>
                          <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                            <Calendar className="w-3 h-3" />
                            <span>{exp.date}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 shrink-0">
                        <div className="text-right">
                          <div className="text-sm sm:text-base font-extrabold text-white">
                            {formatAmount(exp.amount, (exp.currency || 'USD') as CurrencyCode)}
                          </div>
                          {(exp.currency || 'USD') !== activeCurrency ? (
                            <div className="text-[10px] text-teal-400 font-mono font-medium">
                              ≈ {formatAmount(getExpenseInActiveCurrency(exp), activeCurrency)}
                            </div>
                          ) : (
                            <div className="text-[10px] text-slate-400 font-mono">
                              {exp.currency}
                            </div>
                          )}
                        </div>

                        {/* Actions (Edit / Delete) */}
                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition">
                          <button
                            onClick={() => handleOpenEdit(exp)}
                            aria-label="Edit expense"
                            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {deletingId === exp.id ? (
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleDeleteExpense(exp.id)}
                                className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500 text-white"
                              >
                                Delete
                              </button>
                              <button
                                onClick={() => setDeletingId(null)}
                                className="px-1.5 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300"
                              >
                                No
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => setDeletingId(exp.id)}
                              aria-label="Delete expense"
                              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal: Add / Edit Expense */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-slate-900 border border-white/15 p-6 sm:p-8 shadow-2xl text-white relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setModalOpen(false)}
              aria-label="Close dialog"
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>

            <h2 className="text-xl font-bold mb-1">
              {editingExpense ? 'Edit Expense' : 'Log New Expense'}
            </h2>
            <p className="text-xs text-slate-400 mb-6">
              Saved in Firestore under {trip.destination}
            </p>

            {formError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-200 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleSaveExpense} className="space-y-4">
              {/* Amount & Currency */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Amount
                </label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3.5 top-3.5 text-slate-400 font-bold font-mono">
                      {CURRENCY_MAP[currency as CurrencyCode]?.symbol || '$'}
                    </span>
                    <input
                      type="number"
                      step="0.01"
                      min="0.01"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      required
                      autoFocus
                      className="w-full pl-8 pr-4 py-3 rounded-xl glass-input text-lg font-bold text-white placeholder-slate-500"
                    />
                  </div>
                  <select
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value)}
                    className="w-36 px-2.5 py-3 rounded-xl glass-input text-xs font-bold text-slate-200 bg-slate-800"
                  >
                    {CURRENCIES.map((c) => (
                      <option key={c} value={c}>
                        {CURRENCY_MAP[c]?.flag} {c} ({CURRENCY_MAP[c]?.symbol})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Category
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {CATEGORIES.map((c) => {
                    const isSelected = category === c.label;
                    const Icon = c.icon;
                    return (
                      <button
                        key={c.label}
                        type="button"
                        onClick={() => setCategory(c.label)}
                        className={`p-2.5 rounded-xl border text-center transition cursor-pointer flex flex-col items-center gap-1 ${
                          isSelected
                            ? 'bg-teal-500/25 border-teal-400 text-teal-300 font-bold'
                            : 'bg-slate-800/60 border-white/5 text-slate-300 hover:bg-slate-800'
                        }`}
                      >
                        <Icon className="w-4 h-4" />
                        <span className="text-[11px]">{c.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Date */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full px-4 py-2.5 rounded-xl glass-input text-xs text-white"
                />
              </div>

              {/* Note / Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Note / Item Description
                </label>
                <input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Dinner at Le Bistro, Train ticket, Souvenirs..."
                  className="w-full px-4 py-2.5 rounded-xl glass-input text-xs text-white placeholder-slate-500"
                />
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 mt-2 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-teal-500/25 transition cursor-pointer disabled:opacity-60"
              >
                {isSubmitting ? (
                  <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <span>{editingExpense ? 'Update Expense' : 'Save Expense'}</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

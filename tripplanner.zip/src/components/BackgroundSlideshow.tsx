import React, { useState, useEffect, useRef } from 'react';
import { getDestinationImages } from '../data/destinations';
import { Play, Pause, ChevronLeft, ChevronRight, Image as ImageIcon } from 'lucide-react';

interface BackgroundSlideshowProps {
  destination?: string;
}

export const BackgroundSlideshow: React.FC<BackgroundSlideshowProps> = ({ destination }) => {
  const images = getDestinationImages(destination);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [loadedImages, setLoadedImages] = useState<Set<number>>(new Set([0]));
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Reset index when destination changes
  useEffect(() => {
    setCurrentIndex(0);
    setLoadedImages(new Set([0]));
  }, [destination]);

  // Preload all images in the background so transitions are silky smooth
  useEffect(() => {
    images.forEach((src, idx) => {
      const img = new Image();
      img.src = src;
      img.onload = () => {
        setLoadedImages((prev) => new Set(prev).add(idx));
      };
    });
  }, [images]);

  // Auto-advance slideshow every 6 seconds
  useEffect(() => {
    if (!isPlaying || images.length <= 1) return;

    timerRef.current = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 6000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, images.length, currentIndex]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  return (
    <div className="fixed inset-0 w-full h-full -z-10 overflow-hidden pointer-events-none select-none">
      {/* Background Image Layers with Crossfade & Ken Burns Zoom */}
      {images.map((src, index) => {
        const isActive = index === currentIndex;
        return (
          <div
            key={src + index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              isActive ? 'opacity-100 z-0' : 'opacity-0 -z-10'
            }`}
          >
            <img
              src={src}
              alt={destination || 'Scenic travel destination'}
              className={`w-full h-full object-cover object-center ${
                isActive ? 'animate-kenburns' : ''
              }`}
              loading={index === 0 ? 'eager' : 'lazy'}
            />
          </div>
        );
      })}

      {/* Multi-layered Dark Gradient and Frosted Overlays for High Legibility */}
      <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px]" />
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-slate-950/60" />
      <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 via-transparent to-slate-950/70" />

      {/* Subtle Slide Controls (Floating in Bottom Corner) */}
      <div className="absolute bottom-4 right-4 pointer-events-auto flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/70 backdrop-blur-md border border-white/10 text-xs text-slate-300 shadow-lg">
        <span className="flex items-center gap-1.5 font-medium text-slate-300">
          <ImageIcon className="w-3.5 h-3.5 text-teal-400" />
          <span>{destination || 'Explore World'}</span>
        </span>
        <span className="text-slate-600">|</span>
        <span className="font-mono text-[11px] text-slate-400">
          {currentIndex + 1}/{images.length}
        </span>
        <button
          onClick={handlePrev}
          aria-label="Previous slide"
          className="p-1 rounded-full hover:bg-white/10 text-slate-300 transition"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          aria-label={isPlaying ? 'Pause slideshow' : 'Play slideshow'}
          className="p-1 rounded-full hover:bg-white/10 text-slate-300 transition"
        >
          {isPlaying ? <Pause className="w-3.5 h-3.5 text-teal-400" /> : <Play className="w-3.5 h-3.5" />}
        </button>
        <button
          onClick={handleNext}
          aria-label="Next slide"
          className="p-1 rounded-full hover:bg-white/10 text-slate-300 transition"
        >
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};

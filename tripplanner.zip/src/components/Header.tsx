import React, { useState } from 'react';
import {
  Compass,
  MapPin,
  Sparkles,
  Receipt,
  LogOut,
  FolderHeart,
  HelpCircle,
  Menu,
  X,
  User as UserIcon,
} from 'lucide-react';
import { User } from '../firebase';
import { Trip } from '../types';
import { CurrencySelector } from './CurrencySelector';

export type ActiveTab = 'trip-form' | 'recommendations' | 'expense-tracker';

interface HeaderProps {
  user: User | null;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  activeTrip: Trip | null;
  onLogout: () => void;
  onOpenSavedTrips: () => void;
  onOpenSetupGuide: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  activeTab,
  setActiveTab,
  activeTrip,
  onLogout,
  onOpenSavedTrips,
  onOpenSetupGuide,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-slate-950/75 backdrop-blur-xl transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Destination Badge */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('trip-form')}
              className="flex items-center gap-2.5 group text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-400 rounded-lg p-1"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center shadow-lg shadow-teal-500/20 group-hover:scale-105 transition-transform">
                <Compass className="w-5 h-5 text-slate-950 stroke-[2.5]" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-transparent">
                  TripPlanner
                </span>
                <span className="block text-[10px] font-medium text-teal-400 uppercase tracking-widest -mt-1">
                  Travel Suite
                </span>
              </div>
            </button>

            {/* Current Active Trip Chip */}
            {activeTrip && (
              <div className="hidden md:flex items-center gap-2 pl-3 ml-2 border-l border-white/10 text-xs">
                <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300">
                  <MapPin className="w-3.5 h-3.5" />
                  <span className="font-semibold">{activeTrip.destination}</span>
                  <span className="text-teal-400/60">•</span>
                  <span className="text-slate-300">{activeTrip.durationDays}d</span>
                </div>
              </div>
            )}
          </div>

          {/* Desktop Navigation Tabs */}
          {user && (
            <nav className="hidden md:flex items-center gap-1 bg-slate-900/60 p-1 rounded-xl border border-white/10">
              <button
                onClick={() => setActiveTab('trip-form')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'trip-form'
                    ? 'bg-teal-500 text-slate-950 font-semibold shadow-md shadow-teal-500/25'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <MapPin className="w-4 h-4" />
                <span>Trip Details</span>
              </button>

              <button
                onClick={() => setActiveTab('recommendations')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'recommendations'
                    ? 'bg-teal-500 text-slate-950 font-semibold shadow-md shadow-teal-500/25'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Sparkles className="w-4 h-4" />
                <span>Recommendations</span>
              </button>

              <button
                onClick={() => setActiveTab('expense-tracker')}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeTab === 'expense-tracker'
                    ? 'bg-teal-500 text-slate-950 font-semibold shadow-md shadow-teal-500/25'
                    : 'text-slate-300 hover:text-white hover:bg-white/5'
                }`}
              >
                <Receipt className="w-4 h-4" />
                <span>Expense Tracker</span>
              </button>
            </nav>
          )}

          {/* Right Action Icons & User Profile */}
          <div className="hidden md:flex items-center gap-2.5">
            {/* Global Currency Selector */}
            <CurrencySelector />

            {user ? (
              <>
                <button
                  onClick={onOpenSavedTrips}
                  title="My Saved Trips"
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-800/60 hover:bg-slate-800 border border-white/10 rounded-lg transition"
                >
                  <FolderHeart className="w-3.5 h-3.5 text-rose-400" />
                  <span>My Trips</span>
                </button>

                <button
                  onClick={onOpenSetupGuide}
                  title="Setup & API Guide"
                  aria-label="Setup guide"
                  className="p-2 text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded-lg transition"
                >
                  <HelpCircle className="w-4 h-4" />
                </button>

                <div className="h-6 w-px bg-white/10 mx-1" />

                <div className="flex items-center gap-2.5 pl-1">
                  {user.photoURL ? (
                    <img
                      src={user.photoURL}
                      alt={user.displayName || 'User'}
                      className="w-8 h-8 rounded-full border border-teal-400/40 object-cover"
                    />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-slate-800 border border-white/20 flex items-center justify-center text-teal-400">
                      <UserIcon className="w-4 h-4" />
                    </div>
                  )}
                  <div className="text-left hidden lg:block">
                    <p className="text-xs font-semibold text-slate-200 leading-tight truncate max-w-[120px]">
                      {user.displayName || user.email?.split('@')[0] || 'Traveler'}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate max-w-[120px]">
                      {user.email || 'Signed in'}
                    </p>
                  </div>
                </div>

                <button
                  onClick={onLogout}
                  title="Log out"
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-300 hover:text-rose-100 hover:bg-rose-500/10 border border-rose-500/20 rounded-lg transition ml-1"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <button
                onClick={onOpenSetupGuide}
                title="Setup Guide"
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800/60 rounded-lg border border-white/10"
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Documentation</span>
              </button>
            )}
          </div>

          {/* Mobile menu button & currency selector */}
          <div className="md:hidden flex items-center gap-2">
            <CurrencySelector />
            {user && (
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle navigation menu"
                className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && user && (
        <div className="md:hidden border-t border-white/10 bg-slate-950/95 backdrop-blur-2xl px-4 py-4 space-y-2">
          {activeTrip && (
            <div className="p-2.5 rounded-lg bg-teal-500/10 border border-teal-500/20 text-xs text-teal-300 flex items-center justify-between mb-3">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5" />
                {activeTrip.destination}
              </span>
              <span>{activeTrip.durationDays} Days</span>
            </div>
          )}

          <button
            onClick={() => {
              setActiveTab('trip-form');
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'trip-form'
                ? 'bg-teal-500 text-slate-950 font-semibold'
                : 'text-slate-200 hover:bg-white/5'
            }`}
          >
            <MapPin className="w-4 h-4" />
            <span>Trip Details</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('recommendations');
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'recommendations'
                ? 'bg-teal-500 text-slate-950 font-semibold'
                : 'text-slate-200 hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Recommendations</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('expense-tracker');
              setMobileMenuOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-sm font-medium ${
              activeTab === 'expense-tracker'
                ? 'bg-teal-500 text-slate-950 font-semibold'
                : 'text-slate-200 hover:bg-white/5'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Expense Tracker</span>
          </button>

          <div className="pt-2 border-t border-white/10 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenSavedTrips();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/5"
            >
              <FolderHeart className="w-4 h-4 text-rose-400" />
              <span>Saved Trips</span>
            </button>

            <button
              onClick={() => {
                onOpenSetupGuide();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/5"
            >
              <HelpCircle className="w-4 h-4 text-slate-400" />
              <span>Setup & API Instructions</span>
            </button>

            <button
              onClick={() => {
                onLogout();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium text-rose-300 bg-rose-500/10 border border-rose-500/20"
            >
              <LogOut className="w-4 h-4" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

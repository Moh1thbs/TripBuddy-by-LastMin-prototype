import React, { useState, useEffect } from 'react';
import {
  Hotel,
  Utensils,
  Plane,
  Train,
  Bus,
  Car,
  Ship,
  Star,
  MapPin,
  ExternalLink,
  SlidersHorizontal,
  ArrowUpDown,
  Sparkles,
  Info,
  Calendar,
  AlertCircle,
  RefreshCw,
  PlusCircle,
  Check,
} from 'lucide-react';
import {
  Trip,
  HotelRecommendation,
  RestaurantRecommendation,
  TransportOption,
} from '../types';
import { travelService } from '../services/travelService';
import { DetailModal } from './DetailModal';
import { useCurrency } from '../context/CurrencyContext';

interface RecommendationsDashboardProps {
  trip: Trip;
  onEditTrip: () => void;
  onNavigateToExpenses: () => void;
}

type TabType = 'hotels' | 'restaurants' | 'transport';

export const RecommendationsDashboard: React.FC<RecommendationsDashboardProps> = ({
  trip,
  onEditTrip,
  onNavigateToExpenses,
}) => {
  const { formatPriceFromUSD } = useCurrency();
  const [activeTab, setActiveTab] = useState<TabType>('hotels');

  // Data states
  const [hotels, setHotels] = useState<HotelRecommendation[]>([]);
  const [restaurants, setRestaurants] = useState<RestaurantRecommendation[]>([]);
  const [transports, setTransports] = useState<TransportOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Filters & Sorting
  const [priceFilter, setPriceFilter] = useState<string>('all'); // 'all' | '$' | '$$' | '$$$' | '$$$$'
  const [minRatingFilter, setMinRatingFilter] = useState<number>(0); // 0, 4.0, 4.5
  const [availableOnly, setAvailableOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<string>('recommended'); // 'recommended' | 'rating' | 'price-asc' | 'price-desc' | 'distance'

  // Selected item for modal
  const [selectedItem, setSelectedItem] = useState<{
    item: HotelRecommendation | RestaurantRecommendation | TransportOption;
    type: 'hotel' | 'restaurant' | 'transport';
  } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        destination: trip.destination,
        startDate: trip.startDate,
        durationDays: trip.durationDays,
        transportMode: trip.transportMode,
      };

      const [h, r, t] = await Promise.all([
        travelService.getHotels(params),
        travelService.getRestaurants(params),
        travelService.getTransport(params),
      ]);

      setHotels(h);
      setRestaurants(r);
      setTransports(t);
    } catch (err: any) {
      console.error('Error fetching travel recommendations:', err);
      setError('Unable to load travel recommendations. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [trip.destination, trip.startDate, trip.transportMode, trip.durationDays]);

  // Filter & Sort Logic for Hotels
  const filteredHotels = hotels
    .filter((item) => {
      if (priceFilter !== 'all' && item.priceRange !== priceFilter) return false;
      if (minRatingFilter > 0 && item.rating < minRatingFilter) return false;
      if (availableOnly && item.availability === 'High demand') return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'price-asc') return a.pricePerNight - b.pricePerNight;
      if (sortBy === 'price-desc') return b.pricePerNight - a.pricePerNight;
      if (sortBy === 'distance') return a.distanceFromCenterKm - b.distanceFromCenterKm;
      return 0; // recommended
    });

  // Filter & Sort Logic for Restaurants
  const filteredRestaurants = restaurants
    .filter((item) => {
      if (priceFilter !== 'all' && item.priceRange !== priceFilter) return false;
      if (minRatingFilter > 0 && item.rating < minRatingFilter) return false;
      if (availableOnly && item.availability === 'Limited seating') return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'distance') return a.distanceFromCenterKm - b.distanceFromCenterKm;
      return 0;
    });

  // Filter & Sort Logic for Transport
  const filteredTransports = transports
    .filter((item) => {
      if (priceFilter !== 'all' && item.priceRange !== priceFilter) return false;
      if (minRatingFilter > 0 && item.rating < minRatingFilter) return false;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

  const getTransportIcon = () => {
    switch (trip.transportMode) {
      case 'Train':
        return <Train className="w-4 h-4 text-emerald-400" />;
      case 'Bus':
        return <Bus className="w-4 h-4 text-amber-400" />;
      case 'Car':
        return <Car className="w-4 h-4 text-blue-400" />;
      case 'Cruise':
        return <Ship className="w-4 h-4 text-cyan-400" />;
      default:
        return <Plane className="w-4 h-4 text-teal-400" />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
      {/* Top Banner with Destination Context */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 mb-8 border border-white/15 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-2xl">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-teal-400 uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Curated Recommendations</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight flex items-center gap-3">
            <span>{trip.destination}</span>
            <span className="text-xl font-normal text-slate-400 hidden sm:inline">
              • {trip.destinationCountry}
            </span>
          </h1>
          <div className="flex items-center gap-3 mt-3 text-xs sm:text-sm text-slate-300 flex-wrap">
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/60 border border-white/10">
              <Calendar className="w-3.5 h-3.5 text-teal-400" />
              <span>Depart: {trip.startDate}</span>
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/60 border border-white/10">
              <span>{trip.durationDays} Days Stay</span>
            </span>
            <span className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/60 border border-white/10">
              {getTransportIcon()}
              <span>{trip.transportMode}</span>
            </span>
            <span className="text-teal-300/80 font-medium">
              ({trip.monthSeason})
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={onEditTrip}
            className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-xs sm:text-sm font-semibold text-slate-200 border border-white/10 transition cursor-pointer"
          >
            Edit Trip
          </button>
          <button
            onClick={onNavigateToExpenses}
            className="flex-1 md:flex-initial px-4 py-2.5 rounded-xl bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 text-xs sm:text-sm font-semibold transition cursor-pointer"
          >
            Expense Tracker
          </button>
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center justify-between gap-4 mb-6 border-b border-white/10 pb-4 flex-wrap">
        <div className="flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-white/10">
          <button
            onClick={() => setActiveTab('hotels')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              activeTab === 'hotels'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Hotel className="w-4 h-4" />
            <span>Hotels</span>
            <span className="ml-1 text-[11px] px-1.5 py-0.2 rounded-full bg-black/20">
              {hotels.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('restaurants')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              activeTab === 'restaurants'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Utensils className="w-4 h-4" />
            <span>Restaurants</span>
            <span className="ml-1 text-[11px] px-1.5 py-0.2 rounded-full bg-black/20">
              {restaurants.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('transport')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer ${
              activeTab === 'transport'
                ? 'bg-teal-500 text-slate-950 shadow-md shadow-teal-500/25'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            {getTransportIcon()}
            <span>Transport</span>
            <span className="ml-1 text-[11px] px-1.5 py-0.2 rounded-full bg-black/20">
              {transports.length}
            </span>
          </button>
        </div>

        {/* Sort & Filter Controls */}
        <div className="flex items-center gap-3 flex-wrap">
          {/* Price Filter */}
          <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-xl border border-white/10 text-xs">
            <span className="px-2 text-slate-400">Price:</span>
            {['all', '$', '$$', '$$$', '$$$$'].map((tier) => (
              <button
                key={tier}
                onClick={() => setPriceFilter(tier)}
                className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                  priceFilter === tier
                    ? 'bg-teal-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                {tier === 'all' ? 'All' : tier}
              </button>
            ))}
          </div>

          {/* Rating Filter */}
          <div className="flex items-center gap-1 bg-slate-900/70 p-1 rounded-xl border border-white/10 text-xs">
            <span className="px-2 text-slate-400">Rating:</span>
            {[
              { val: 0, label: 'All' },
              { val: 4.0, label: '4.0+' },
              { val: 4.5, label: '4.5+' },
            ].map((r) => (
              <button
                key={r.val}
                onClick={() => setMinRatingFilter(r.val)}
                className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                  minRatingFilter === r.val
                    ? 'bg-teal-500 text-slate-950 font-bold'
                    : 'text-slate-300 hover:bg-white/5'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-1.5 bg-slate-900/70 px-3 py-1.5 rounded-xl border border-white/10 text-xs text-slate-300">
            <ArrowUpDown className="w-3.5 h-3.5 text-teal-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-transparent border-none text-slate-200 focus:outline-none cursor-pointer text-xs"
            >
              <option value="recommended" className="bg-slate-900">Recommended</option>
              <option value="rating" className="bg-slate-900">Rating: High to Low</option>
              <option value="price-asc" className="bg-slate-900">Price: Low to High</option>
              <option value="price-desc" className="bg-slate-900">Price: High to Low</option>
              <option value="distance" className="bg-slate-900">Distance: Closest</option>
            </select>
          </div>
        </div>
      </div>

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div
              key={i}
              className="glass-card rounded-3xl p-4 overflow-hidden border border-white/10 animate-pulse space-y-4"
            >
              <div className="w-full h-48 bg-slate-800/60 rounded-2xl" />
              <div className="h-5 bg-slate-800/80 rounded-md w-3/4" />
              <div className="h-4 bg-slate-800/60 rounded-md w-1/2" />
              <div className="flex justify-between pt-2">
                <div className="h-6 bg-slate-800/80 rounded w-1/4" />
                <div className="h-6 bg-slate-800/80 rounded w-1/3" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Error State */}
      {error && !loading && (
        <div className="glass-panel p-10 rounded-3xl text-center border border-rose-500/20 max-w-md mx-auto my-12">
          <AlertCircle className="w-10 h-10 text-rose-400 mx-auto mb-3" />
          <h3 className="text-lg font-bold text-white mb-1">Failed to fetch data</h3>
          <p className="text-xs text-slate-300 mb-5">{error}</p>
          <button
            onClick={fetchData}
            className="px-5 py-2.5 rounded-xl bg-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 mx-auto cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Retry Search</span>
          </button>
        </div>
      )}

      {/* Content Tab 1: HOTELS */}
      {!loading && !error && activeTab === 'hotels' && (
        <div>
          {filteredHotels.length === 0 ? (
            <div className="glass-panel p-12 rounded-3xl text-center border border-white/10 max-w-md mx-auto my-10">
              <Hotel className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-white">No hotels match your filters</h3>
              <p className="text-xs text-slate-400 mt-1 mb-4">
                Try widening your price range or rating filters.
              </p>
              <button
                onClick={() => {
                  setPriceFilter('all');
                  setMinRatingFilter(0);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-medium cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredHotels.map((hotel) => (
                <div
                  key={hotel.id}
                  onClick={() => setSelectedItem({ item: hotel, type: 'hotel' })}
                  className="glass-card glass-card-hover rounded-3xl overflow-hidden cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    {/* Hotel Card Image */}
                    <div className="relative h-52 w-full overflow-hidden">
                      <img
                        src={hotel.photo}
                        alt={hotel.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                      {/* Availability Badge */}
                      <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-950/75 backdrop-blur-md text-teal-300 border border-teal-500/30">
                        {hotel.availability}
                      </span>

                      {/* Provider Badge */}
                      <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold bg-teal-500 text-slate-950 shadow-sm">
                        {hotel.provider}
                      </span>

                      {/* Bottom Info inside photo */}
                      <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-white">
                        <span className="flex items-center gap-1 font-bold bg-slate-900/60 px-2 py-0.5 rounded-full backdrop-blur-sm">
                          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                          <span>{hotel.rating}</span>
                          <span className="text-[10px] text-slate-300 font-normal">
                            ({hotel.reviewsCount})
                          </span>
                        </span>
                        <span className="text-[11px] text-slate-200 font-medium bg-slate-900/60 px-2 py-0.5 rounded-full">
                          {hotel.priceRange}
                        </span>
                      </div>
                    </div>

                    {/* Hotel Details Content */}
                    <div className="p-5 space-y-3">
                      <div>
                        <h3 className="text-lg font-bold text-white group-hover:text-teal-300 transition-colors line-clamp-1">
                          {hotel.name}
                        </h3>
                        <p className="text-xs text-slate-300 line-clamp-2 mt-1">
                          {hotel.tagline}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                        <span className="truncate">{hotel.neighborhood}</span>
                        <span>•</span>
                        <span className="shrink-0">{hotel.distanceFromCenterKm} km from center</span>
                      </div>

                      {/* Amenities Pills */}
                      <div className="flex items-center gap-1.5 flex-wrap pt-1">
                        {hotel.amenities.slice(0, 3).map((amenity, i) => (
                          <span
                            key={i}
                            className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300 border border-white/5"
                          >
                            {amenity}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom CTA */}
                  <div className="p-5 pt-0 border-t border-white/5 mt-3 flex items-center justify-between">
                    <div>
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider">Per night</div>
                      <div className="text-base font-extrabold text-teal-300">
                        {formatPriceFromUSD(hotel.pricePerNight)}{' '}
                        <span className="text-xs text-slate-400 font-normal">est.</span>
                      </div>
                    </div>

                    <a
                      href={hotel.bookingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="px-3.5 py-2 rounded-xl bg-teal-500/20 hover:bg-teal-500 text-teal-300 hover:text-slate-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-teal-500/30"
                    >
                      <span>Book</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Content Tab 2: RESTAURANTS */}
      {!loading && !error && activeTab === 'restaurants' && (
        <div>
          {filteredRestaurants.length === 0 ? (
            <div className="glass-panel p-12 rounded-3xl text-center border border-white/10 max-w-md mx-auto my-10">
              <Utensils className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-white">No dining options match filters</h3>
              <p className="text-xs text-slate-400 mt-1 mb-4">
                Try widening your price range or rating filters.
              </p>
              <button
                onClick={() => {
                  setPriceFilter('all');
                  setMinRatingFilter(0);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-200 text-xs font-medium cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRestaurants.map((restaurant) => (
                <div
                  key={restaurant.id}
                  onClick={() => setSelectedItem({ item: restaurant, type: 'restaurant' })}
                  className="glass-card glass-card-hover rounded-3xl overflow-hidden cursor-pointer flex flex-col justify-between group"
                >
                  <div>
                    {/* Restaurant Photo */}
                    <div className="relative h-52 w-full overflow-hidden">
                      <img
                        src={restaurant.photo}
                        alt={restaurant.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />

                      <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-slate-950/75 backdrop-blur-md text-amber-300 border border-amber-500/30">
                        {restaurant.availability}
                      </span>

                      <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                        {restaurant.provider}
                      </span>

                      <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-white">
                        <span className="flex items-center gap-1 font-bold bg-slate-900/60 px-2 py-0.5 rounded-full backdrop-blur-sm">
                          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                          <span>{restaurant.rating}</span>
                          <span className="text-[10px] text-slate-300 font-normal">
                            ({restaurant.reviewsCount})
                          </span>
                        </span>
                        <span className="text-[11px] text-slate-200 font-medium bg-slate-900/60 px-2 py-0.5 rounded-full">
                          {restaurant.priceRange}
                        </span>
                      </div>
                    </div>

                    {/* Details */}
                    <div className="p-5 space-y-3">
                      <div>
                        <div className="text-[11px] font-bold text-teal-400 uppercase tracking-wider mb-0.5">
                          {restaurant.cuisine}
                        </div>
                        <h3 className="text-lg font-bold text-white group-hover:text-teal-300 transition-colors line-clamp-1">
                          {restaurant.name}
                        </h3>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <MapPin className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                        <span className="truncate">{restaurant.neighborhood}</span>
                        <span>•</span>
                        <span className="shrink-0">{restaurant.distanceFromCenterKm} km from center</span>
                      </div>

                      {/* Specialties */}
                      <div className="flex items-center gap-1.5 flex-wrap pt-1">
                        {restaurant.specialties.map((spec, i) => (
                          <span
                            key={i}
                            className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800/80 text-slate-300 border border-white/5"
                          >
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Reserve CTA */}
                  <div className="p-5 pt-0 border-t border-white/5 mt-3 flex items-center justify-between">
                    <span className="text-xs text-slate-400 truncate max-w-[150px]">
                      {restaurant.openingHours.split('(')[0]}
                    </span>

                    <a
                      href={restaurant.bookingUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-400 text-amber-300 hover:text-slate-950 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer border border-amber-500/30"
                    >
                      <span>Reserve</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Content Tab 3: TRANSPORT */}
      {!loading && !error && activeTab === 'transport' && (
        <div className="space-y-4">
          {filteredTransports.length === 0 ? (
            <div className="glass-panel p-12 rounded-3xl text-center border border-white/10 max-w-md mx-auto my-10">
              <Plane className="w-10 h-10 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-semibold text-white">No transport options match</h3>
              <p className="text-xs text-slate-400 mt-1 mb-4">
                Try widening your price range or rating filters.
              </p>
            </div>
          ) : (
            filteredTransports.map((item) => (
              <div
                key={item.id}
                onClick={() => setSelectedItem({ item, type: 'transport' })}
                className="glass-card glass-card-hover rounded-3xl p-5 sm:p-6 cursor-pointer flex flex-col md:flex-row items-start md:items-center justify-between gap-6 group"
              >
                <div className="flex items-start gap-4 flex-1">
                  <div className="w-12 h-12 rounded-2xl bg-teal-500/15 border border-teal-500/30 flex items-center justify-center text-teal-300 shrink-0 group-hover:scale-105 transition-transform">
                    {getTransportIcon()}
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-800 text-teal-300 border border-white/10">
                        {item.operator}
                      </span>
                      <span className="text-xs font-medium text-slate-400">• {item.mode}</span>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        {item.availability}
                      </span>
                    </div>

                    <h3 className="text-base sm:text-lg font-bold text-white group-hover:text-teal-300 transition-colors">
                      {item.title}
                    </h3>

                    {/* Departure / Arrival Stations */}
                    <div className="flex items-center gap-2 text-xs text-slate-300 flex-wrap">
                      <span className="font-semibold text-white">{item.departureTime}</span>
                      <span className="text-slate-400">({item.departureStation})</span>
                      <span className="text-teal-400">➔</span>
                      <span className="font-semibold text-white">{item.arrivalTime}</span>
                      <span className="text-slate-400">({item.arrivalStation})</span>
                    </div>

                    {/* Features checklist */}
                    <div className="flex items-center gap-2 flex-wrap pt-1">
                      {item.features.map((feat, i) => (
                        <span
                          key={i}
                          className="text-[11px] text-slate-400 flex items-center gap-1"
                        >
                          <Check className="w-3 h-3 text-teal-400" />
                          <span>{feat}</span>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right price & CTA */}
                <div className="flex md:flex-col items-center md:items-end justify-between w-full md:w-auto shrink-0 pt-3 md:pt-0 border-t md:border-t-0 border-white/10 gap-3">
                  <div className="text-left md:text-right">
                    <div className="text-[10px] text-slate-400 uppercase tracking-wider">Est. Fare</div>
                    <div className="text-xl font-extrabold text-teal-300">
                      {formatPriceFromUSD(item.price)}{' '}
                      <span className="text-xs text-slate-400 font-normal">/ person</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {item.duration}
                    </div>
                  </div>

                  <a
                    href={item.bookingUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="px-5 py-2.5 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-teal-500/20 transition cursor-pointer"
                  >
                    <span>Check Tickets</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Detail Popup Modal */}
      {selectedItem && (
        <DetailModal
          item={selectedItem.item}
          type={selectedItem.type}
          onClose={() => setSelectedItem(null)}
          tripDestination={trip.destination}
          tripDates={`${trip.startDate} (${trip.durationDays}d)`}
        />
      )}
    </div>
  );
};

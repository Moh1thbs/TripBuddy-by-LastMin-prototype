import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Terminal,
  Key,
  ShieldCheck,
  Cloud,
  Check,
  Copy,
  ExternalLink,
  Layers,
} from 'lucide-react';

interface SetupGuideModalProps {
  onClose: () => void;
}

export const SetupGuideModal: React.FC<SetupGuideModalProps> = ({ onClose }) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const envSnippet = `# Firebase Web Configuration
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="your-project.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="your-project-id"
VITE_FIREBASE_STORAGE_BUCKET="your-project.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="your-sender-id"
VITE_FIREBASE_APP_ID="your-app-id"

# Live Third-Party Travel APIs (Optional - defaults to rich realistic adapters)
VITE_BOOKING_API_KEY="your-rapidapi-booking-key"
VITE_GOOGLE_PLACES_API_KEY="your-google-places-key"
VITE_SKYSCANNER_API_KEY="your-skyscanner-key"`;

  const runLocalSnippet = `# 1. Clone & install dependencies
git clone <your-repo>
cd tripplanner
npm install

# 2. Run local development server
npm run dev

# 3. Open in browser at http://localhost:3000`;

  const deploySnippet = `# 1. Build the production bundle
npm run build

# 2. Initialize Firebase Hosting (if not already initialized)
firebase login
firebase init hosting
# Set "dist" as your public directory
# Configure as a single-page app (SPA): Yes

# 3. Deploy to live Firebase Hosting
firebase deploy --only hosting,firestore:rules`;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[88vh] overflow-y-auto rounded-3xl bg-slate-900 border border-white/15 p-6 sm:p-8 shadow-2xl text-white relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close setup guide"
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-slate-300 hover:text-white"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-500/30 flex items-center justify-center text-teal-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white">TripPlanner Technical & Setup Guide</h2>
            <p className="text-xs text-slate-400">
              Architecture, Firebase Configuration, Live APIs & Deployment Instructions
            </p>
          </div>
        </div>

        <div className="space-y-6 text-sm text-slate-300">
          {/* Section 1: Overview */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-400" />
              <span>Architecture & Project Structure</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              TripPlanner is engineered as a single continuous React UI with smooth screen transitions:
            </p>
            <ul className="text-xs list-disc list-inside space-y-1 text-slate-300 pl-1">
              <li><strong>Screen 1 (Auth):</strong> Firebase Authentication with email/password and Google OAuth.</li>
              <li><strong>Screen 2 (Trip Form):</strong> Destination autocomplete, calendar date picker, season calculation, duration presets, and transport cards saved to Firestore.</li>
              <li><strong>Screen 3 (Dashboard):</strong> Hotels, Restaurants, and Transport with swappable adapter layers and deep-link booking triggers.</li>
              <li><strong>Expense Tracker:</strong> Interactive budget utilization bar, SVG donut chart, and real-time Firestore sync via <code className="text-teal-300">onSnapshot</code>.</li>
            </ul>
          </div>

          {/* Section 2: Environment Variables */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-teal-400" />
                <span>1. Environment Variables (.env)</span>
              </h3>
              <button
                onClick={() => copyToClipboard(envSnippet, 'env')}
                className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300"
              >
                {copiedKey === 'env' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'env' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 overflow-x-auto border border-white/5">
              {envSnippet}
            </pre>
          </div>

          {/* Section 3: Firestore Security Rules */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>2. Firestore Security Rules</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Rules have been verified and deployed directly via <code className="text-teal-300">deploy_firebase</code>. Each authenticated user has strict partitioned access to their own profile, trips, and expenses:
            </p>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-teal-300/90 overflow-x-auto border border-white/5">
{`service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /users/{userId}/trips/{tripId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      match /expenses/{expenseId} {
        allow read, write: if request.auth != null && request.auth.uid == userId;
      }
    }
  }
}`}
            </pre>
          </div>

          {/* Section 4: Running Locally */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-teal-400" />
                <span>3. Running Locally</span>
              </h3>
              <button
                onClick={() => copyToClipboard(runLocalSnippet, 'run')}
                className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300"
              >
                {copiedKey === 'run' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'run' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 overflow-x-auto border border-white/5">
              {runLocalSnippet}
            </pre>
          </div>

          {/* Section 5: Deploying to Firebase Hosting */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Cloud className="w-4 h-4 text-teal-400" />
                <span>4. Deploying to Firebase Hosting</span>
              </h3>
              <button
                onClick={() => copyToClipboard(deploySnippet, 'deploy')}
                className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300"
              >
                {copiedKey === 'deploy' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'deploy' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 overflow-x-auto border border-white/5">
              {deploySnippet}
            </pre>
          </div>

          {/* Section 6: Swapping Live Travel APIs */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-white/5 space-y-2">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ExternalLink className="w-4 h-4 text-teal-400" />
              <span>5. Connecting Third-Party Live Travel APIs</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Check <code className="text-teal-300">src/services/travelService.ts</code> for the swappable adapter architecture:
            </p>
            <ul className="text-xs list-disc list-inside space-y-1 text-slate-300 pl-1">
              <li><strong>Hotels:</strong> <code className="text-teal-300">LiveBookingDotComAdapter</code> implements <code className="text-teal-300">IHotelAdapter</code>.</li>
              <li><strong>Restaurants:</strong> <code className="text-teal-300">LiveGooglePlacesRestaurantAdapter</code> implements <code className="text-teal-300">IRestaurantAdapter</code>.</li>
              <li><strong>Transport:</strong> <code className="text-teal-300">LiveSkyscannerTransportAdapter</code> implements <code className="text-teal-300">ITransportAdapter</code>.</li>
            </ul>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-white/10 text-right">
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-teal-500 text-slate-950 font-bold text-xs cursor-pointer"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};

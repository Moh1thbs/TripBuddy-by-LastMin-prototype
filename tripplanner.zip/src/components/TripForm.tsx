import React, { useState, useEffect, useRef } from 'react';
import {
  MapPin,
  Calendar,
  Clock,
  Plane,
  Train,
  Bus,
  Car,
  Ship,
  Sparkles,
  ArrowRight,
  Search,
  Check,
  Globe2,
  AlertCircle,
  Sun,
  Snowflake,
  Flower2,
  Leaf,
} from 'lucide-react';
import { TransportMode, Trip, DestinationItem } from '../types';
import { POPULAR_DESTINATIONS } from '../data/destinations';
import { saveTrip } from '../services/firestoreService';
import { User } from '../firebase';
import { useCurrency } from '../context/CurrencyContext';

interface TripFormProps {
  user: User;
  onTripSaved: (trip: Trip) => void;
  initialTrip?: Trip | null;
}

export const TripForm: React.FC<TripFormProps> = ({ user, onTripSaved, initialTrip }) => {
  const { currency: activeCurrency } = useCurrency();
  // 1. Destination
  const [destinationInput, setDestinationInput] = useState(
    initialTrip ? `${initialTrip.destination}, ${initialTrip.destinationCountry}` : 'Paris, France'
  );
  const [selectedDestination, setSelectedDestination] = useState<DestinationItem | null>(() => {
    if (initialTrip) {
      return (
        POPULAR_DESTINATIONS.find(
          (d) => d.city.toLowerCase() === initialTrip.destination.toLowerCase()
        ) || null
      );
    }
    return POPULAR_DESTINATIONS[0];
  });
  const [showAutocomplete, setShowAutocomplete] = useState(false);
  const autocompleteRef = useRef<HTMLDivElement>(null);

  // 2. Start Date & Season
  // Default to a realistic near-future date
  const getDefaultDate = () => {
    const d = new Date();
    d.setDate(d.getDate() + 21); // 3 weeks ahead
    return d.toISOString().split('T')[0];
  };

  const [startDate, setStartDate] = useState(initialTrip?.startDate || getDefaultDate());
  const [monthSeason, setMonthSeason] = useState(initialTrip?.monthSeason || 'Autumn / Oct 2026');

  // Compute season & month display from date
  const updateSeasonFromDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr + 'T00:00:00');
      const monthNames = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December'
      ];
      const monthIdx = d.getMonth();
      const monthName = monthNames[monthIdx];
      const year = d.getFullYear();

      let season = 'Spring';
      if (monthIdx === 11 || monthIdx === 0 || monthIdx === 1) season = 'Winter';
      else if (monthIdx >= 2 && monthIdx <= 4) season = 'Spring';
      else if (monthIdx >= 5 && monthIdx <= 7) season = 'Summer';
      else season = 'Autumn';

      setMonthSeason(`${season} • ${monthName} ${year}`);
    } catch {
      // fallback
    }
  };

  useEffect(() => {
    if (startDate) {
      updateSeasonFromDate(startDate);
    }
  }, [startDate]);

  // 3. Duration in Days
  const [durationDays, setDurationDays] = useState<number>(initialTrip?.durationDays || 7);

  // 4. Preferred Transport Mode
  const [transportMode, setTransportMode] = useState<TransportMode>(
    initialTrip?.transportMode || 'Flight'
  );

  // Form State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Close autocomplete on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (autocompleteRef.current && !autocompleteRef.current.contains(e.target as Node)) {
        setShowAutocomplete(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredDestinations = POPULAR_DESTINATIONS.filter((d) => {
    const query = destinationInput.toLowerCase().trim();
    if (!query) return true;
    return (
      d.city.toLowerCase().includes(query) ||
      d.country.toLowerCase().includes(query) ||
      d.code.toLowerCase().includes(query)
    );
  });

  const handleSelectDestination = (dest: DestinationItem) => {
    setSelectedDestination(dest);
    setDestinationInput(`${dest.city}, ${dest.country}`);
    setShowAutocomplete(false);
    // clear error if any
    setErrors((prev) => ({ ...prev, destination: '' }));
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!destinationInput.trim()) {
      newErrors.destination = 'Please enter or select a holiday destination.';
    }

    if (!startDate) {
      newErrors.startDate = 'Please choose your departure date.';
    }

    if (!durationDays || durationDays < 1) {
      newErrors.durationDays = 'Stay duration must be at least 1 day.';
    } else if (durationDays > 90) {
      newErrors.durationDays = 'Maximum stay duration is 90 days.';
    }

    if (!transportMode) {
      newErrors.transportMode = 'Please choose a preferred transport mode.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    try {
      // Split city and country
      const parts = destinationInput.split(',');
      const city = parts[0]?.trim() || destinationInput.trim();
      const country = parts[1]?.trim() || selectedDestination?.country || 'International';

      const tripData: Omit<Trip, 'id'> = {
        userId: user.uid,
        destination: city,
        destinationCountry: country,
        destinationCode: selectedDestination?.code,
        startDate,
        monthSeason,
        durationDays,
        transportMode,
        currency: selectedDestination?.currency || activeCurrency || 'USD',
        createdAt: Date.now(),
      };

      const tripId = await saveTrip(tripData);

      const savedTrip: Trip = {
        ...tripData,
        id: tripId,
      };

      onTripSaved(savedTrip);
    } catch (err) {
      console.error('Error saving trip:', err);
      setErrors({ form: 'Failed to save trip to Firestore. Please try again.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const getSeasonIcon = () => {
    if (monthSeason.includes('Winter')) return <Snowflake className="w-4 h-4 text-cyan-300" />;
    if (monthSeason.includes('Spring')) return <Flower2 className="w-4 h-4 text-emerald-300" />;
    if (monthSeason.includes('Summer')) return <Sun className="w-4 h-4 text-amber-300" />;
    return <Leaf className="w-4 h-4 text-amber-400" />;
  };

  const transportCards: Array<{
    mode: TransportMode;
    label: string;
    sublabel: string;
    icon: React.ReactNode;
  }> = [
    {
      mode: 'Flight',
      label: 'Flight',
      sublabel: 'Airlines & direct routes',
      icon: <Plane className="w-5 h-5" />,
    },
    {
      mode: 'Train',
      label: 'Train',
      sublabel: 'Scenic & high-speed rail',
      icon: <Train className="w-5 h-5" />,
    },
    {
      mode: 'Bus',
      label: 'Bus / Coach',
      sublabel: 'Intercity budget lines',
      icon: <Bus className="w-5 h-5" />,
    },
    {
      mode: 'Car',
      label: 'Car Rental',
      sublabel: 'Road trip & self-drive',
      icon: <Car className="w-5 h-5" />,
    },
    {
      mode: 'Cruise',
      label: 'Cruise / Ferry',
      sublabel: 'Sea voyages & coastal trips',
      icon: <Ship className="w-5 h-5" />,
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 sm:py-12">
      {/* Top Banner / Heading */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-semibold uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Screen 2 • Trip Designer</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Where is your next adventure?
        </h1>
        <p className="text-sm sm:text-base text-slate-300 mt-2 max-w-xl mx-auto">
          Set your destination and travel dates. We'll generate personalized hotels,
          top-tier dining, and transport options in seconds.
        </p>
      </div>

      {/* Main Glass Form Card */}
      <div className="glass-panel rounded-3xl p-6 sm:p-10 shadow-2xl border border-white/15 relative overflow-hidden">
        {errors.form && (
          <div className="mb-6 p-4 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-200 text-sm flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
            <span>{errors.form}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* STEP 1: Destination Autocomplete */}
          <div className="relative" ref={autocompleteRef}>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-teal-400" />
                <span>1. Holiday Destination</span>
              </label>
              <span className="text-xs text-slate-400 hidden sm:inline">
                Type or pick from popular hubs
              </span>
            </div>

            <div className="relative">
              <input
                type="text"
                value={destinationInput}
                onChange={(e) => {
                  setDestinationInput(e.target.value);
                  setShowAutocomplete(true);
                }}
                onFocus={() => setShowAutocomplete(true)}
                placeholder="Search city or country (e.g. Paris, Tokyo, Rome, New York)..."
                className="w-full pl-11 pr-10 py-3.5 rounded-2xl glass-input text-base sm:text-lg font-medium text-white placeholder-slate-400 transition"
              />
              <Search className="w-5 h-5 text-teal-400 absolute left-3.5 top-4 pointer-events-none" />
              {destinationInput && (
                <button
                  type="button"
                  onClick={() => {
                    setDestinationInput('');
                    setSelectedDestination(null);
                    setShowAutocomplete(true);
                  }}
                  className="absolute right-3.5 top-4 text-xs font-semibold text-slate-400 hover:text-slate-200 bg-slate-800/80 px-2 py-0.5 rounded-full"
                >
                  Clear
                </button>
              )}
            </div>

            {errors.destination && (
              <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.destination}
              </p>
            )}

            {/* Autocomplete Dropdown */}
            {showAutocomplete && (
              <div className="absolute z-50 left-0 right-0 mt-2 bg-slate-900/95 backdrop-blur-2xl border border-white/15 rounded-2xl shadow-2xl overflow-hidden max-h-72 overflow-y-auto">
                <div className="p-2 border-b border-white/10 text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-3">
                  Suggested Destinations
                </div>
                {filteredDestinations.length > 0 ? (
                  filteredDestinations.map((dest) => (
                    <button
                      key={dest.city}
                      type="button"
                      onClick={() => handleSelectDestination(dest)}
                      className="w-full px-3.5 py-2.5 text-left flex items-center justify-between hover:bg-teal-500/15 border-b border-white/5 last:border-0 transition group cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={dest.heroImage}
                          alt={dest.city}
                          className="w-10 h-10 rounded-xl object-cover border border-white/10 shrink-0"
                        />
                        <div>
                          <div className="text-sm font-semibold text-white group-hover:text-teal-300 flex items-center gap-1.5">
                            <span>{dest.city}</span>
                            <span className="text-xs font-normal text-slate-400">
                              , {dest.country}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 line-clamp-1">
                            {dest.description}
                          </p>
                        </div>
                      </div>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-white/10">
                        {dest.code}
                      </span>
                    </button>
                  ))
                ) : (
                  <div className="p-4 text-center text-sm text-slate-400">
                    <p>No exact preset match for "{destinationInput}".</p>
                    <p className="text-xs text-teal-400 mt-1 font-medium">
                      Press continue to plan for this custom destination!
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Quick Popular Destination Badges */}
            <div className="flex items-center gap-2 mt-3 flex-wrap">
              <span className="text-xs text-slate-400">Popular:</span>
              {POPULAR_DESTINATIONS.slice(0, 5).map((dest) => (
                <button
                  key={dest.city}
                  type="button"
                  onClick={() => handleSelectDestination(dest)}
                  className={`text-xs px-2.5 py-1 rounded-full border transition cursor-pointer ${
                    destinationInput.includes(dest.city)
                      ? 'bg-teal-500 text-slate-950 font-semibold border-teal-400'
                      : 'bg-slate-900/50 hover:bg-slate-800 text-slate-300 border-white/10'
                  }`}
                >
                  {dest.city}
                </button>
              ))}
            </div>
          </div>

          {/* STEP 2: Month / Season of Travel & Exact Start Date */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2 mb-2">
                <Calendar className="w-4 h-4 text-teal-400" />
                <span>2. Departure Date</span>
              </label>
              <input
                type="date"
                value={startDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-4 py-3 rounded-2xl glass-input text-sm text-white font-medium transition cursor-pointer"
              />
              {errors.startDate && (
                <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  {errors.startDate}
                </p>
              )}
            </div>

            <div>
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2 mb-2">
                {getSeasonIcon()}
                <span>Month & Season of Travel</span>
              </label>
              <div className="px-4 py-3 rounded-2xl glass-input flex items-center justify-between text-sm text-slate-200 border border-white/10 bg-slate-900/50">
                <span className="font-semibold text-teal-300">{monthSeason}</span>
                <span className="text-[11px] text-slate-400">Auto-calculated</span>
              </div>
            </div>
          </div>

          {/* STEP 3: Number of Days of Stay */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-semibold text-slate-200 flex items-center gap-2">
                <Clock className="w-4 h-4 text-teal-400" />
                <span>3. Duration of Stay</span>
              </label>
              <span className="text-sm font-bold text-teal-300">
                {durationDays} {durationDays === 1 ? 'Day' : 'Days'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 mb-3">
              {[
                { days: 3, label: '3 Days', sub: 'Weekend' },
                { days: 5, label: '5 Days', sub: 'Short Break' },
                { days: 7, label: '7 Days', sub: '1 Week' },
                { days: 10, label: '10 Days', sub: 'Extended' },
                { days: 14, label: '14 Days', sub: '2 Weeks' },
              ].map((preset) => (
                <button
                  key={preset.days}
                  type="button"
                  onClick={() => setDurationDays(preset.days)}
                  className={`p-2.5 rounded-xl border text-center transition cursor-pointer ${
                    durationDays === preset.days
                      ? 'bg-teal-500/20 border-teal-400 text-teal-200 font-semibold shadow-md'
                      : 'bg-slate-900/40 border-white/10 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="text-sm font-bold">{preset.label}</div>
                  <div className="text-[10px] text-slate-400">{preset.sub}</div>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <input
                type="range"
                min="1"
                max="30"
                value={durationDays}
                onChange={(e) => setDurationDays(Number(e.target.value))}
                className="w-full accent-teal-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
              />
              <div className="flex items-center gap-1.5 shrink-0">
                <input
                  type="number"
                  min="1"
                  max="90"
                  value={durationDays}
                  onChange={(e) => setDurationDays(Math.max(1, Number(e.target.value)))}
                  className="w-16 px-2 py-1 text-center rounded-lg glass-input text-sm font-bold text-teal-300"
                />
                <span className="text-xs text-slate-400">days</span>
              </div>
            </div>
            {errors.durationDays && (
              <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.durationDays}
              </p>
            )}
          </div>

          {/* STEP 4: Preferred Mode of Transport */}
          <div>
            <label className="text-sm font-semibold text-slate-200 flex items-center gap-2 mb-3">
              <Plane className="w-4 h-4 text-teal-400" />
              <span>4. Preferred Mode of Transport</span>
            </label>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {transportCards.map((item) => {
                const isSelected = transportMode === item.mode;
                return (
                  <button
                    key={item.mode}
                    type="button"
                    onClick={() => {
                      setTransportMode(item.mode);
                      setErrors((prev) => ({ ...prev, transportMode: '' }));
                    }}
                    className={`relative p-3.5 rounded-2xl border text-left transition-all duration-200 cursor-pointer flex flex-col justify-between ${
                      isSelected
                        ? 'bg-gradient-to-b from-teal-500/25 to-slate-900 border-teal-400 text-white shadow-lg shadow-teal-500/20 ring-1 ring-teal-400'
                        : 'bg-slate-900/50 hover:bg-slate-800/80 border-white/10 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                          isSelected
                            ? 'bg-teal-400 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-300'
                        }`}
                      >
                        {item.icon}
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-teal-400 text-slate-950 flex items-center justify-center">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-white">{item.label}</div>
                      <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {item.sublabel}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
            {errors.transportMode && (
              <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" />
                {errors.transportMode}
              </p>
            )}
          </div>

          {/* Submit CTA */}
          <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-400 text-center sm:text-left">
              <span>Automatically saved to your account in Firestore</span>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-teal-500 via-emerald-400 to-teal-400 hover:from-teal-400 hover:to-emerald-300 text-slate-950 font-extrabold text-base flex items-center justify-center gap-3 shadow-xl shadow-teal-500/30 transition transform hover:-translate-y-0.5 cursor-pointer disabled:opacity-60"
            >
              {isSubmitting ? (
                <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Sparkles className="w-5 h-5" />
                  <span>Show me recommendations</span>
                  <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

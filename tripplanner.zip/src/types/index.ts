export type TransportMode = 'Flight' | 'Train' | 'Bus' | 'Car' | 'Cruise';

export type TravelSeason = 'Spring' | 'Summer' | 'Autumn' | 'Winter';

export interface Trip {
  id?: string;
  userId: string;
  destination: string;
  destinationCountry: string;
  destinationCode?: string;
  startDate: string; // YYYY-MM-DD
  monthSeason: string;
  durationDays: number;
  transportMode: TransportMode;
  budget?: number;
  currency?: string;
  createdAt: number;
  updatedAt?: number;
}

export interface HotelRecommendation {
  id: string;
  name: string;
  tagline: string;
  photo: string;
  gallery: string[];
  rating: number;
  reviewsCount: number;
  pricePerNight: number;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  distanceFromCenterKm: number;
  neighborhood: string;
  availability: 'Available' | 'Few rooms left' | 'High demand' | 'Available today';
  amenities: string[];
  highlights: string[];
  bookingUrl: string;
  provider: 'Booking.com' | 'Expedia' | 'Agoda' | 'Direct';
  address: string;
}

export interface RestaurantRecommendation {
  id: string;
  name: string;
  cuisine: string;
  photo: string;
  gallery: string[];
  rating: number;
  reviewsCount: number;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  distanceFromCenterKm: number;
  neighborhood: string;
  availability: 'Tables available' | 'Reservation required' | 'Walk-ins welcome' | 'Limited seating';
  specialties: string[];
  features: string[];
  bookingUrl: string;
  provider: 'OpenTable' | 'Resy' | 'TripAdvisor' | 'TheFork';
  address: string;
  openingHours: string;
}

export interface TransportOption {
  id: string;
  mode: TransportMode;
  operator: string;
  photo?: string;
  title: string;
  duration: string;
  departureTime: string;
  arrivalTime: string;
  departureStation: string;
  arrivalStation: string;
  price: number;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  rating: number;
  availability: 'Seats available' | 'Few seats remaining' | 'Scheduled daily' | 'Filling fast' | 'Available today';
  features: string[];
  bookingUrl: string;
  provider: 'Skyscanner' | 'Google Flights' | 'Trainline' | 'Rentalcars' | 'Omio';
}

export type ExpenseCategory =
  | 'Stay'
  | 'Food'
  | 'Transport'
  | 'Activities'
  | 'Shopping'
  | 'Other';

export interface Expense {
  id: string;
  tripId: string;
  userId: string;
  amount: number;
  category: ExpenseCategory;
  date: string;
  note: string;
  currency: string;
  createdAt: number;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
  createdAt: number;
}

export interface DestinationItem {
  city: string;
  country: string;
  code: string;
  description: string;
  heroImage: string;
  gallery: string[];
  currency: string;
}

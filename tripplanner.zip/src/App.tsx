import React, { useState, useEffect } from 'react';
import {
  auth,
  onAuthStateChanged,
  signOut,
  User,
} from './firebase';
import { Trip } from './types';
import { getUserTrips } from './services/firestoreService';
import { BackgroundSlideshow } from './components/BackgroundSlideshow';
import { Header, ActiveTab } from './components/Header';
import { AuthModal } from './components/AuthModal';
import { TripForm } from './components/TripForm';
import { RecommendationsDashboard } from './components/RecommendationsDashboard';
import { ExpenseTracker } from './components/ExpenseTracker';
import { SavedTripsModal } from './components/SavedTripsModal';
import { SetupGuideModal } from './components/SetupGuideModal';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authInitialized, setAuthInitialized] = useState(false);

  // App navigation state
  const [activeTab, setActiveTab] = useState<ActiveTab>('trip-form');
  const [activeTrip, setActiveTrip] = useState<Trip | null>(null);

  // Modals
  const [savedTripsModalOpen, setSavedTripsModalOpen] = useState(false);
  const [setupGuideModalOpen, setSetupGuideModalOpen] = useState(false);

  // Listen to Firebase Auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setAuthInitialized(true);

      if (currentUser) {
        // Load latest trip if user has one
        try {
          const trips = await getUserTrips(currentUser.uid);
          if (trips.length > 0) {
            setActiveTrip(trips[0]);
          }
        } catch (err) {
          console.error('Failed to load user trips upon auth:', err);
        }
      } else {
        setActiveTrip(null);
        setActiveTab('trip-form');
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Logout error:', err);
    }
  };

  const handleTripSaved = (trip: Trip) => {
    setActiveTrip(trip);
    // Smooth transition to Recommendations
    setActiveTab('recommendations');
  };

  const handleSelectTrip = (trip: Trip) => {
    setActiveTrip(trip);
    setActiveTab('recommendations');
  };

  const handlePlanNewTrip = () => {
    setActiveTrip(null);
    setActiveTab('trip-form');
  };

  const handleUpdateTripBudget = (newBudget: number) => {
    if (activeTrip) {
      setActiveTrip({ ...activeTrip, budget: newBudget });
    }
  };

  // Determine current destination for the live background slideshow
  const slideshowDestination = activeTrip?.destination || (activeTab === 'trip-form' ? 'Paris' : undefined);

  // Loading initial auth session
  if (!authInitialized) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-teal-500 to-emerald-400 flex items-center justify-center animate-bounce shadow-xl shadow-teal-500/30">
          <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
        </div>
        <p className="text-xs text-slate-400 font-medium tracking-wider uppercase mt-4">
          Loading TripPlanner...
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col relative selection:bg-teal-500 selection:text-white">
      {/* Full-Screen Auto-moving Background Slideshow with Ken Burns Effect */}
      <BackgroundSlideshow destination={slideshowDestination} />

      {/* Main Top Header */}
      <Header
        user={user}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeTrip={activeTrip}
        onLogout={handleLogout}
        onOpenSavedTrips={() => setSavedTripsModalOpen(true)}
        onOpenSetupGuide={() => setSetupGuideModalOpen(true)}
      />

      {/* Continuous UI Viewport */}
      <main className="flex-1 transition-all duration-300">
        {!user ? (
          // Screen 1: Login / Sign up
          <AuthModal onSuccess={() => setActiveTab('trip-form')} />
        ) : (
          <>
            {/* Screen 2: Trip details form */}
            {activeTab === 'trip-form' && (
              <div className="animate-in fade-in duration-300">
                <TripForm
                  user={user}
                  onTripSaved={handleTripSaved}
                  initialTrip={activeTrip}
                />
              </div>
            )}

            {/* Screen 3: Recommendations dashboard */}
            {activeTab === 'recommendations' && (
              <div className="animate-in fade-in duration-300">
                {activeTrip ? (
                  <RecommendationsDashboard
                    trip={activeTrip}
                    onEditTrip={() => setActiveTab('trip-form')}
                    onNavigateToExpenses={() => setActiveTab('expense-tracker')}
                  />
                ) : (
                  <div className="max-w-md mx-auto my-20 p-8 glass-panel rounded-3xl text-center border border-white/10">
                    <h3 className="text-lg font-bold text-white mb-2">No Active Trip Selected</h3>
                    <p className="text-xs text-slate-300 mb-6">
                      Plan a new trip or choose one from your saved adventures to view personalized recommendations.
                    </p>
                    <button
                      onClick={() => setActiveTab('trip-form')}
                      className="px-6 py-3 rounded-xl bg-teal-500 text-slate-950 font-bold text-xs inline-flex items-center gap-2"
                    >
                      <span>Create a Trip</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Screen 4 / Tab: Expense tracker */}
            {activeTab === 'expense-tracker' && (
              <div className="animate-in fade-in duration-300">
                {activeTrip ? (
                  <ExpenseTracker
                    user={user}
                    trip={activeTrip}
                    onUpdateTripBudget={handleUpdateTripBudget}
                  />
                ) : (
                  <div className="max-w-md mx-auto my-20 p-8 glass-panel rounded-3xl text-center border border-white/10">
                    <h3 className="text-lg font-bold text-white mb-2">Select a Trip to Track Expenses</h3>
                    <p className="text-xs text-slate-300 mb-6">
                      Expenses and budget are linked to specific planned trips in Firestore.
                    </p>
                    <button
                      onClick={() => setActiveTab('trip-form')}
                      className="px-6 py-3 rounded-xl bg-teal-500 text-slate-950 font-bold text-xs"
                    >
                      Plan or Select a Trip
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer subtle tag */}
      <footer className="w-full py-4 text-center text-[11px] text-slate-400 border-t border-white/5 bg-slate-950/70 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between flex-wrap gap-2">
          <span>TripPlanner &bull; Built with React, Tailwind CSS &amp; Firebase</span>
          <button
            onClick={() => setSetupGuideModalOpen(true)}
            className="text-teal-400 hover:text-teal-300 underline underline-offset-2"
          >
            Setup Guide &amp; API Docs
          </button>
        </div>
      </footer>

      {/* Saved Trips Drawer / Modal */}
      {savedTripsModalOpen && user && (
        <SavedTripsModal
          user={user}
          activeTripId={activeTrip?.id}
          onSelectTrip={handleSelectTrip}
          onPlanNewTrip={handlePlanNewTrip}
          onClose={() => setSavedTripsModalOpen(false)}
        />
      )}

      {/* Setup Guide Modal */}
      {setupGuideModalOpen && (
        <SetupGuideModal onClose={() => setSetupGuideModalOpen(false)} />
      )}
    </div>
  );
}

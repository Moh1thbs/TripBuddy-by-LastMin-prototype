import { DestinationItem } from '../types';

export const POPULAR_DESTINATIONS: DestinationItem[] = [
  {
    city: 'Paris',
    country: 'France',
    code: 'PAR',
    description: 'City of Light, famous for the Eiffel Tower, Louvre, haute cuisine, and romantic Seine river cruises.',
    heroImage: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1920&q=80', // Eiffel Tower
      'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=1920&q=80', // Louvre pyramid
      'https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?auto=format&fit=crop&w=1920&q=80', // Eiffel sunset
      'https://images.unsplash.com/photo-1520939817895-060bdef4ad1b?auto=format&fit=crop&w=1920&q=80', // Paris cafe
      'https://images.unsplash.com/photo-1509356843151-3e7d96241e11?auto=format&fit=crop&w=1920&q=80', // Montmartre
    ],
    currency: 'EUR',
  },
  {
    city: 'Tokyo',
    country: 'Japan',
    code: 'TYO',
    description: 'Electrifying neon metropolis fusing ancient shrines, Michelin dining, high-speed rail, and anime culture.',
    heroImage: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1920&q=80', // Tokyo tower
      'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?auto=format&fit=crop&w=1920&q=80', // Shinjuku neon
      'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1920&q=80', // Senso-ji
      'https://images.unsplash.com/photo-1536098561742-ca998e48cbcc?auto=format&fit=crop&w=1920&q=80', // Shibuya crossing
      'https://images.unsplash.com/photo-1528164344705-475426879c0d?auto=format&fit=crop&w=1920&q=80', // Cherry blossoms
    ],
    currency: 'JPY',
  },
  {
    city: 'Rome',
    country: 'Italy',
    code: 'ROM',
    description: 'The Eternal City with the Colosseum, Vatican museums, piazzas, rich espresso, and world-class pasta.',
    heroImage: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1552832230-c0197dd311b5?auto=format&fit=crop&w=1920&q=80', // Colosseum
      'https://images.unsplash.com/photo-1531572753322-ad063cecc140?auto=format&fit=crop&w=1920&q=80', // St Peter's Vatican
      'https://images.unsplash.com/photo-1525874684015-58379d421a52?auto=format&fit=crop&w=1920&q=80', // Trevi Fountain
      'https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?auto=format&fit=crop&w=1920&q=80', // Roman street
      'https://images.unsplash.com/photo-1529260830199-42c24126f198?auto=format&fit=crop&w=1920&q=80', // Spanish Steps
    ],
    currency: 'EUR',
  },
  {
    city: 'New York',
    country: 'United States',
    code: 'NYC',
    description: 'The city that never sleeps, featuring Central Park, Broadway, Manhattan skyline, and world cuisine.',
    heroImage: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=1920&q=80', // Manhattan skyline
      'https://images.unsplash.com/photo-1534430480872-3498386e7856?auto=format&fit=crop&w=1920&q=80', // Empire State & Brooklyn Bridge
      'https://images.unsplash.com/photo-1506146332389-18140dc7b2fb?auto=format&fit=crop&w=1920&q=80', // Central Park
      'https://images.unsplash.com/photo-1518391846015-55a9cc003b25?auto=format&fit=crop&w=1920&q=80', // Times Square
      'https://images.unsplash.com/photo-1485738422979-f5c462d49f74?auto=format&fit=crop&w=1920&q=80', // Statue of Liberty
    ],
    currency: 'USD',
  },
  {
    city: 'Barcelona',
    country: 'Spain',
    code: 'BCN',
    description: 'Mediterranean gem brimming with Gaudí architecture, sunny beaches, tapas bars, and Gothic Quarter vibes.',
    heroImage: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1583422409516-2895a77efded?auto=format&fit=crop&w=1920&q=80', // Sagrada Familia
      'https://images.unsplash.com/photo-1539037116277-4db20889f2d4?auto=format&fit=crop&w=1920&q=80', // Park Guell
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80', // Barceloneta beach
      'https://images.unsplash.com/photo-1511527661048-7fe73d85e9a4?auto=format&fit=crop&w=1920&q=80', // Gothic Quarter
      'https://images.unsplash.com/photo-1564221710304-0b37c8b9d729?auto=format&fit=crop&w=1920&q=80', // Casa Batllo
    ],
    currency: 'EUR',
  },
  {
    city: 'London',
    country: 'United Kingdom',
    code: 'LON',
    description: 'Iconic capital rich in royal landmarks, West End theater, Thames views, and multicultural street markets.',
    heroImage: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1920&q=80', // Big Ben
      'https://images.unsplash.com/photo-1526129318478-62ed807ebdf9?auto=format&fit=crop&w=1920&q=80', // Tower Bridge
      'https://images.unsplash.com/photo-1486299267070-83823f5448dd?auto=format&fit=crop&w=1920&q=80', // Red phone booth
      'https://images.unsplash.com/photo-1520986606214-8b456906c813?auto=format&fit=crop&w=1920&q=80', // London Eye
      'https://images.unsplash.com/photo-1533929736458-ca588d08c8be?auto=format&fit=crop&w=1920&q=80', // Thames dusk
    ],
    currency: 'GBP',
  },
  {
    city: 'Dubai',
    country: 'United Arab Emirates',
    code: 'DXB',
    description: 'Futuristic oasis with towering skyscrapers, luxury shopping, desert dunes, and golden beaches.',
    heroImage: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=1920&q=80', // Burj Khalifa skyline
      'https://images.unsplash.com/photo-1518684079-3c830dcef090?auto=format&fit=crop&w=1920&q=80', // Marina skyline
      'https://images.unsplash.com/photo-1546412414-e1885259563a?auto=format&fit=crop&w=1920&q=80', // Desert safari
      'https://images.unsplash.com/photo-1580674684081-7617fbf3d745?auto=format&fit=crop&w=1920&q=80', // Palm Jumeirah
    ],
    currency: 'AED',
  },
  {
    city: 'Kyoto',
    country: 'Japan',
    code: 'UKY',
    description: 'Cultural heart of Japan with thousands of classical Buddhist temples, gardens, imperial palaces, and shrines.',
    heroImage: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1920&q=80', // Fushimi Inari
      'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1920&q=80', // Bamboo grove
      'https://images.unsplash.com/photo-1545569341-9eb8b30979d9?auto=format&fit=crop&w=1920&q=80', // Kinkaku-ji
    ],
    currency: 'JPY',
  },
  {
    city: 'Amsterdam',
    country: 'Netherlands',
    code: 'AMS',
    description: 'Charming canal rings, historic gabled houses, cycling culture, and world-renowned museum quarters.',
    heroImage: 'https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?auto=format&fit=crop&w=1920&q=80', // Canal bikes
      'https://images.unsplash.com/photo-1534351590666-13e3e96b5017?auto=format&fit=crop&w=1920&q=80', // Bridges & night lights
      'https://images.unsplash.com/photo-1583295125721-766a0088cb3b?auto=format&fit=crop&w=1920&q=80', // Traditional houses
    ],
    currency: 'EUR',
  },
  {
    city: 'Sydney',
    country: 'Australia',
    code: 'SYD',
    description: 'Sun-drenched coastal capital known for the Sydney Opera House, Harbour Bridge, and Bondi surfing.',
    heroImage: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1920&q=80', // Opera House
      'https://images.unsplash.com/photo-1528072164453-f4e8ef0d4750?auto=format&fit=crop&w=1920&q=80', // Harbour bridge
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80', // Bondi beach
    ],
    currency: 'AUD',
  },
  {
    city: 'Singapore',
    country: 'Singapore',
    code: 'SIN',
    description: 'City in a Garden featuring Marina Bay Sands, Supertree Grove, hawker centers, and botanical wonder.',
    heroImage: 'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1525625293386-3f8f99389edd?auto=format&fit=crop&w=1920&q=80', // Marina Bay Sands
      'https://images.unsplash.com/photo-1565967511849-76a60a516170?auto=format&fit=crop&w=1920&q=80', // Supertrees
      'https://images.unsplash.com/photo-1506059612708-99d6c258160e?auto=format&fit=crop&w=1920&q=80', // Jewel Changi
    ],
    currency: 'SGD',
  },
  {
    city: 'Santorini',
    country: 'Greece',
    code: 'JTR',
    description: 'Cycladic paradise of whitewashed houses, cobalt blue domes, dramatic volcanic cliffs, and legendary sunsets.',
    heroImage: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1920&q=80',
    gallery: [
      'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1920&q=80', // Oia blue domes
      'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1920&q=80', // Sunset caldera
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80', // Aegean sea
    ],
    currency: 'EUR',
  }
];

export const FALLBACK_SCENIC_IMAGES = [
  'https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=1920&q=80', // Travel map & passport
  'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1920&q=80', // Road trip desert
  'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80', // Tropical coast
  'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1920&q=80', // Alpine lake boat
  'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80', // Mountain valley
];

export function getDestinationImages(destinationName?: string): string[] {
  if (!destinationName) return FALLBACK_SCENIC_IMAGES;

  const normalized = destinationName.toLowerCase().trim();
  const match = POPULAR_DESTINATIONS.find(
    (d) =>
      normalized.includes(d.city.toLowerCase()) ||
      normalized.includes(d.country.toLowerCase()) ||
      d.city.toLowerCase().includes(normalized)
  );

  if (match && match.gallery.length > 0) {
    return match.gallery;
  }

  // If custom destination, produce high quality unsplash query links with fallback
  const cityQuery = encodeURIComponent(destinationName.trim());
  return [
    `https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=1920&q=80`,
    `https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=1920&q=80`,
    `https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1920&q=80`,
    `https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?auto=format&fit=crop&w=1920&q=80`,
    `https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1920&q=80`,
  ];
}
